# FarhadAIStudio — V1 (Phase 1 + Phase 2: Foundation & Homepage)

A clean, modern AI Developer Platform for discovering AI coding tools, learning
deployment, exploring projects, and connecting for development services.

**Phase 1** shipped the foundation: branding, architecture, routing, layout,
reusable components, and SEO basics. **Phase 2** builds the full homepage on
top of that foundation — Hero, What is FarhadAIStudio, AI Coding, Domain
Services, Hosting & Deployment, Featured Projects, Why Choose Us, and a
closing CTA — using only the reusable components already in place. No
dashboards, auth, databases, or backend — still intentional.

## Tech stack

- React 18 + TypeScript
- Vite
- Tailwind CSS v4 (CSS-first `@theme` design tokens)
- React Router v6
- Framer Motion
- Lucide React (icons)
- React Helmet Async (SEO)

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`).

```bash
npm run build     # type-checks and builds for production into /dist
npm run preview   # preview the production build locally
npm run lint      # run ESLint
```

## Project structure

```
src/
├── assets/        static assets (images, icons)
├── components/    reusable UI building blocks (Button, Container, Navbar, ...)
├── layouts/       page chrome shared across routes (MainLayout)
├── pages/         one file per route
├── sections/      page-specific composed sections (e.g. sections/home/Hero.tsx)
├── styles/        global CSS + Tailwind v4 design tokens
├── hooks/         reusable React hooks
├── services/      future API/service integrations (empty in Phase 1)
├── utils/         small pure helper functions
├── data/          static data (nav links, etc.)
├── constants/     site-wide constants (SITE config)
└── types/         shared TypeScript types
```

## Brand identity

The visual direction is a **developer's workshop / terminal** aesthetic:
dark ink surfaces, an amber "signal" accent, an electric-blue secondary
accent, and a monospace type layer used for structural labels (`// eyebrow`,
`$ command`) to tie the UI vocabulary to the developer-tools subject matter.

Design tokens live in `src/styles/index.css` under `@theme` — colors,
type scale, radius, and shadows are all defined there and consumed as
Tailwind utilities (`bg-ink`, `text-signal`, `rounded-[var(--radius-lg)]`, etc.).
Update tokens there to re-theme the whole app.

The logo (`src/components/Logo.tsx`) is a text-based placeholder by design —
swap in an SVG mark later without touching any call sites.

## Routes

| Path              | Page             |
|-------------------|------------------|
| `/`               | Home             |
| `/ai-coding`      | AI Coding        |
| `/domain-hosting` | Domain & Hosting |
| `/projects`        | Projects         |
| `/resources`      | Resources        |
| `/contact`        | Contact          |
| `/privacy`        | Privacy Policy (placeholder) |
| `/terms`          | Terms of Service (placeholder) |
| `*`               | 404 Not Found    |

All routes are code-split with `React.lazy` and rendered inside `MainLayout`.

## Homepage sections (Phase 2)

Composed in `src/pages/Home.tsx` from `src/sections/home/`:

1. **Hero** — headline, description, primary/secondary CTA, animated terminal
   illustration, ambient background glows.
2. **WhatIs** — the four things the platform covers (coding assistance,
   domain guidance, hosting & deployment, resources).
3. **AICodingSection** — Claude, ChatGPT, Gemini, and Farhadoo AI (coming
   soon) as feature cards, no API calls.
4. **DomainServices** — registration guidance, suggestions, security, DNS
   basics (informational only).
5. **HostingDeployment** — Vercel, Firebase, Netlify, Hostinger comparison
   cards.
6. **FeaturedProjects** — Live Attendance and Farhadoo AI project cards.
7. **WhyChooseUs** — six differentiators.
8. **CTA** — links to AI Coding, Projects, and Contact.

All cards reuse `IconCard`, `Badge`, `ToolCard`, and `FeaturedProjectCard`
from `src/components/` — no section duplicates card markup.

## Notes for Phase 2

- `PlaceholderGrid` and `PageHero` are shared components used by the content
  pages (AI Coding, Domain & Hosting, Projects, Resources) — replace the
  placeholder grid with real cards/data without changing page structure.
- `src/data/` and `src/types/` are set up to hold real content collections
  (tools, projects, guides) as flat arrays or, later, fetched data.
- `src/services/` is intentionally empty — this is where API clients would
  go if/when a backend is introduced.
