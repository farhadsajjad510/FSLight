import type { ReactNode } from 'react'

export interface NavLink {
  label: string
  path: string
}

export interface WithChildren {
  children: ReactNode
}

export interface ToolCard {
  id: string
  name: string
  category: string
  description: string
  tag?: string
}

export interface ProjectCard {
  id: string
  title: string
  summary: string
  stack: string[]
  status: 'shipped' | 'in-progress' | 'concept'
}

export interface ResourceCard {
  id: string
  title: string
  summary: string
  type: 'guide' | 'reference' | 'checklist'
  readTime: string
}
