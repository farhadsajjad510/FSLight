import type { LucideIcon } from 'lucide-react'
import { Lightbulb, MousePointerClick, Code2, Eye, TestTube2, Rocket } from 'lucide-react'

export interface WorkflowStep {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

/**
 * The six-step loop this platform teaches for working with AI on real
 * code: idea through deploy. Purely informational — no tool is wired
 * up to any of these steps yet.
 */
export const WORKFLOW_STEPS: WorkflowStep[] = [
  {
    id: 'idea',
    icon: Lightbulb,
    title: 'Idea',
    description: 'Start with a clear problem or feature you actually want to build.',
  },
  {
    id: 'choose-ai',
    icon: MousePointerClick,
    title: 'Choose AI',
    description: 'Pick the assistant that fits the task \u2014 not just the one you always reach for.',
  },
  {
    id: 'generate-code',
    icon: Code2,
    title: 'Generate Code',
    description: 'Prompt with context: what you\u2019re building, constraints, and the stack in use.',
  },
  {
    id: 'review-code',
    icon: Eye,
    title: 'Review Code',
    description: 'Read every line before it ships \u2014 AI output is a draft, not a final answer.',
  },
  {
    id: 'test',
    icon: TestTube2,
    title: 'Test',
    description: 'Run it, break it on purpose, and confirm it does what you actually asked for.',
  },
  {
    id: 'deploy',
    icon: Rocket,
    title: 'Deploy',
    description: 'Ship with confidence once the code has earned it \u2014 not before.',
  },
]
