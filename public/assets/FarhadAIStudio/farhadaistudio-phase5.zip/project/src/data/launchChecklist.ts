export interface ChecklistItem {
  id: string
  label: string
}

/**
 * Informational launch checklist. Checked state (if the UI offers it)
 * lives only in local component state \u2014 nothing is saved or synced.
 */
export const LAUNCH_CHECKLIST: ChecklistItem[] = [
  { id: 'project-completed', label: 'Project Completed' },
  { id: 'responsive-design', label: 'Responsive Design' },
  { id: 'seo-ready', label: 'SEO Ready' },
  { id: 'performance-optimized', label: 'Performance Optimized' },
  { id: 'domain-connected', label: 'Domain Connected' },
  { id: 'ssl-enabled', label: 'SSL Enabled' },
  { id: 'analytics-ready', label: 'Analytics Ready' },
  { id: 'final-testing', label: 'Final Testing' },
]
