import type { LucideIcon } from 'lucide-react'
import { Sparkles, Bot, Code, Gauge, Smartphone, GraduationCap } from 'lucide-react'

export interface Feature {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

export const WHY_FEATURES: Feature[] = [
  {
    id: 'modern-dev',
    icon: Sparkles,
    title: 'Modern development',
    description: 'Built on a current, well-maintained stack — no legacy patterns to work around.',
  },
  {
    id: 'ai-assistance',
    icon: Bot,
    title: 'AI assistance',
    description: 'Every recommendation here reflects tools we actually use to build and ship.',
  },
  {
    id: 'clean-code',
    icon: Code,
    title: 'Clean code',
    description: 'Modular, typed, and readable — the codebase behind this platform practices what it teaches.',
  },
  {
    id: 'performance',
    icon: Gauge,
    title: 'Performance',
    description: 'Lazy-loaded routes and a lean bundle keep the platform fast on any connection.',
  },
  {
    id: 'responsive',
    icon: Smartphone,
    title: 'Responsive design',
    description: 'Designed mobile-first, so it holds up from a small phone screen to a wide desktop.',
  },
  {
    id: 'continuous-learning',
    icon: GraduationCap,
    title: 'Continuous learning',
    description: 'Guides and tool comparisons are revisited as the AI coding landscape keeps moving.',
  },
]
