import type { LucideIcon } from 'lucide-react'
import { Search, Shield, Network, Sparkles } from 'lucide-react'

export interface DomainService {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

export const DOMAIN_SERVICES: DomainService[] = [
  {
    id: 'registration',
    icon: Search,
    title: 'Domain registration guidance',
    description:
      'Understand registrars, pricing, and renewal terms before you commit to a domain.',
  },
  {
    id: 'suggestions',
    icon: Sparkles,
    title: 'Domain suggestions',
    description:
      'Tips for naming your project well — short, memorable, and available across the extensions that matter.',
  },
  {
    id: 'security',
    icon: Shield,
    title: 'Domain security',
    description:
      'The basics of WHOIS privacy, registrar locking, and keeping your domain from being hijacked.',
  },
  {
    id: 'dns',
    icon: Network,
    title: 'DNS basics',
    description:
      'A plain-language walkthrough of A, CNAME, MX, and TXT records — what they do and when you need them.',
  },
]
