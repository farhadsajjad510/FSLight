import type { LucideIcon } from 'lucide-react'
import { Lightbulb, ClipboardList, PenTool, Code2, TestTube2, Rocket, Wrench } from 'lucide-react'

export interface WorkflowPhase {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

export const DEVELOPMENT_WORKFLOW: WorkflowPhase[] = [
  {
    id: 'idea',
    icon: Lightbulb,
    title: 'Idea',
    description: 'Define the problem worth solving and who it\u2019s actually for.',
  },
  {
    id: 'planning',
    icon: ClipboardList,
    title: 'Planning',
    description: 'Scope features, pick the stack, and map out how the pieces fit together.',
  },
  {
    id: 'design',
    icon: PenTool,
    title: 'Design',
    description: 'Shape the UI and flows before writing production code.',
  },
  {
    id: 'development',
    icon: Code2,
    title: 'Development',
    description: 'Build in focused phases, with AI assisting where it genuinely helps.',
  },
  {
    id: 'testing',
    icon: TestTube2,
    title: 'Testing',
    description: 'Verify every flow works the way it\u2019s supposed to, on real devices.',
  },
  {
    id: 'deployment',
    icon: Rocket,
    title: 'Deployment',
    description: 'Ship to production with a domain, hosting, and SSL in place.',
  },
  {
    id: 'maintenance',
    icon: Wrench,
    title: 'Maintenance',
    description: 'Keep improving after launch \u2014 fixes, performance, and new features.',
  },
]
