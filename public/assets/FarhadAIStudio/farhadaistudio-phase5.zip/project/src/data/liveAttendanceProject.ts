export interface LiveAttendanceProject {
  intro: string
  purpose: string
  keyFeatures: string[]
  technologies: string[]
  version: string
  status: 'in-progress' | 'shipped'
  openProjectHref: string
  learnMoreHref: string
}

/**
 * Live Attendance is showcased as an independent product \u2014 this page
 * only links out to it, nothing from that app is embedded or wired
 * into FarhadAIStudio itself.
 */
export const LIVE_ATTENDANCE: LiveAttendanceProject = {
  intro:
    'A real-time attendance platform built for universities, colleges, schools, and academies \u2014 replacing manual sign-in sheets with a fast, reliable digital flow.',
  purpose:
    'To give institutions a modern, trustworthy way to track attendance live, with roles for owners, admins, teachers, and students all handled in one system.',
  keyFeatures: [
    'AI-assisted live attendance tracking',
    'Role-based dashboards (Owner, Admin, Teacher, Student/CR)',
    'QR-based department & class connection',
    'Real-time sync across devices',
  ],
  technologies: ['React', 'Vite', 'Firebase', 'Firestore', 'Auth'],
  version: 'v1.0',
  status: 'in-progress',
  openProjectHref: '#',
  learnMoreHref: '/contact',
}
