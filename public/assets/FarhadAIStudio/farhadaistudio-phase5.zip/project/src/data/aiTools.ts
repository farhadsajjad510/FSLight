export interface AITool {
  id: string
  name: string
  maker: string
  description: string
  strengths: string[]
  status: 'available' | 'coming-soon'
}

export const AI_TOOLS: AITool[] = [
  {
    id: 'claude',
    name: 'Claude',
    maker: 'Anthropic',
    description:
      'A careful, context-aware coding partner — strong at reasoning through larger codebases and multi-step tasks.',
    strengths: ['Long context', 'Careful reasoning', 'Agentic coding'],
    status: 'available',
  },
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    maker: 'OpenAI',
    description:
      'A versatile, widely-integrated assistant with a huge plugin and tooling ecosystem around it.',
    strengths: ['Broad ecosystem', 'Fast iteration', 'Plugin support'],
    status: 'available',
  },
  {
    id: 'gemini',
    name: 'Gemini',
    maker: 'Google',
    description:
      'Deeply integrated with Google\u2019s tooling — a solid pick if your stack already lives in that ecosystem.',
    strengths: ['Google integration', 'Multimodal input', 'Fast responses'],
    status: 'available',
  },
  {
    id: 'farhadoo-ai',
    name: 'Farhadoo AI',
    maker: 'FarhadAIStudio',
    description:
      'Our own AI in development — built around the specific workflows this platform is designed for.',
    strengths: ['Purpose-built', 'Platform-native', 'In development'],
    status: 'coming-soon',
  },
]
