import type { NavLink } from '@/types'

export const NAV_LINKS: NavLink[] = [
  { label: 'Home', path: '/' },
  { label: 'AI Coding', path: '/ai-coding' },
  { label: 'Domain & Hosting', path: '/domain-hosting' },
  { label: 'Projects', path: '/projects' },
  { label: 'Resources', path: '/resources' },
  { label: 'Contact', path: '/contact' },
]
