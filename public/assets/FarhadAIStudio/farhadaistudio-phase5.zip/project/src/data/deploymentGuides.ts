import type { LucideIcon } from 'lucide-react'
import { Rocket, Flame, Triangle, Waves, Link2 } from 'lucide-react'

export interface DeploymentGuide {
  id: string
  icon: LucideIcon
  title: string
  description: string
  readTime: string
}

/**
 * Informational guide cards \u2014 no interactive deploy flow, just
 * pointers on what each path involves.
 */
export const DEPLOYMENT_GUIDES: DeploymentGuide[] = [
  {
    id: 'react-vite',
    icon: Rocket,
    title: 'React + Vite Deployment',
    description:
      'Build a production bundle with `vite build`, then serve the generated /dist folder from any static host.',
    readTime: '4 min read',
  },
  {
    id: 'firebase-hosting-guide',
    icon: Flame,
    title: 'Firebase Hosting',
    description:
      'Install the Firebase CLI, initialize hosting, and deploy your build folder with a single `firebase deploy`.',
    readTime: '5 min read',
  },
  {
    id: 'vercel-guide',
    icon: Triangle,
    title: 'Vercel Deployment',
    description:
      'Connect a git repository and let Vercel detect your framework automatically \u2014 every push gets its own preview URL.',
    readTime: '3 min read',
  },
  {
    id: 'netlify-guide',
    icon: Waves,
    title: 'Netlify Deployment',
    description:
      'Drag-and-drop a build folder or connect a repo for continuous deploys, with build settings configured per project.',
    readTime: '3 min read',
  },
  {
    id: 'custom-domain',
    icon: Link2,
    title: 'Custom Domain Connection',
    description:
      'Point your domain\u2019s DNS records at your host, verify ownership, and wait for propagation before it goes live.',
    readTime: '6 min read',
  },
]
