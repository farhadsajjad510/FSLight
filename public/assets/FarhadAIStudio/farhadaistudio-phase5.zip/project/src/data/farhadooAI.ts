export interface RoadmapPhase {
  id: string
  phase: string
  label: string
}

export interface FarhadooAIProject {
  tagline: string
  futureVision: string
  plannedFeatures: string[]
  techStackPlanned: string[]
  roadmap: RoadmapPhase[]
}

/**
 * Farhadoo AI is not built yet \u2014 every field here is a stated
 * intention, not a shipped capability. Kept clearly "coming soon"
 * wherever it's displayed.
 */
export const FARHADOO_AI: FarhadooAIProject = {
  tagline: 'AI Coding Assistant',
  futureVision:
    'An AI assistant purpose-built for FarhadAIStudio\u2019s own workflows \u2014 not a general chatbot bolted on afterward, but one shaped around real project needs.',
  plannedFeatures: [
    'Context-aware coding help',
    'Project-specific guidance',
    'Learning mode for beginners',
    'Deep FarhadAIStudio platform integration',
  ],
  techStackPlanned: ['TypeScript', 'AI/ML APIs', 'Firebase', 'Vector Search'],
  roadmap: [
    { id: 'phase-1', phase: 'Phase 1', label: 'Core AI engine & prompt design' },
    { id: 'phase-2', phase: 'Phase 2', label: 'Platform integration & workflows' },
    { id: 'phase-3', phase: 'Phase 3', label: 'Public beta access' },
  ],
}
