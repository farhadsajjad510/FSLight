import type { LucideIcon } from 'lucide-react'
import { Triangle, Flame, Waves, Box } from 'lucide-react'

export interface HostingPlatform {
  id: string
  icon: LucideIcon
  name: string
  description: string
  bestFor: string
}

export const HOSTING_PLATFORMS: HostingPlatform[] = [
  {
    id: 'vercel',
    icon: Triangle,
    name: 'Vercel',
    description: 'Zero-config deploys built around frontend frameworks like Next.js.',
    bestFor: 'Frontend & full-stack React apps',
  },
  {
    id: 'firebase',
    icon: Flame,
    name: 'Firebase',
    description: 'Hosting paired with managed backend services when you need more than static.',
    bestFor: 'Apps needing auth, DB, or functions',
  },
  {
    id: 'netlify',
    icon: Waves,
    name: 'Netlify',
    description: 'Fast static and JAMstack hosting with a simple, git-based deploy workflow.',
    bestFor: 'Static sites & JAMstack projects',
  },
  {
    id: 'hostinger',
    icon: Box,
    name: 'Hostinger',
    description: 'Traditional web hosting — a straightforward option for classic stacks.',
    bestFor: 'Traditional / budget hosting',
  },
]
