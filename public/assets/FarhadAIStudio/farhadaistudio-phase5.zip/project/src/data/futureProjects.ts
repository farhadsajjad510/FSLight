import type { LucideIcon } from 'lucide-react'
import { FileText, FileStack, Presentation, Wrench, Layers } from 'lucide-react'

export interface FutureProject {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

export const FUTURE_PROJECTS: FutureProject[] = [
  {
    id: 'ai-notes-generator',
    icon: FileText,
    title: 'AI Notes Generator',
    description: 'Turn raw material into clean, structured study or meeting notes.',
  },
  {
    id: 'ai-pdf-generator',
    icon: FileStack,
    title: 'AI PDF Generator',
    description: 'Generate polished, ready-to-share PDF documents from simple input.',
  },
  {
    id: 'ai-presentation-builder',
    icon: Presentation,
    title: 'AI Presentation Builder',
    description: 'Draft full slide decks from an outline, ready to refine and present.',
  },
  {
    id: 'developer-toolkit',
    icon: Wrench,
    title: 'Developer Toolkit',
    description: 'A collection of small utilities for everyday AI-assisted development.',
  },
  {
    id: 'future-saas-products',
    icon: Layers,
    title: 'Future SaaS Products',
    description: 'Additional products under the FarhadAIStudio brand, still taking shape.',
  },
]
