import type { LucideIcon } from 'lucide-react'
import { Triangle, Flame, Waves, Box, Cloud } from 'lucide-react'

export interface HostingPlatformDetail {
  id: string
  icon: LucideIcon
  name: string
  accent: 'signal' | 'pulse' | 'online'
  description: string
  bestUseCases: string[]
  advantages: string[]
  learnMoreHref: string
}

/**
 * Richer hosting comparison used on the Domain & Hosting page. Kept
 * separate from data/hostingPlatforms.ts, which powers the lighter
 * homepage summary cards \u2014 different shape, same platforms.
 */
export const HOSTING_PLATFORMS_DETAILED: HostingPlatformDetail[] = [
  {
    id: 'vercel',
    icon: Triangle,
    name: 'Vercel',
    accent: 'signal',
    description:
      'Zero-config deploys built around frontend frameworks, with instant previews for every git push.',
    bestUseCases: ['React / Next.js apps', 'Frontend-heavy projects', 'Preview deployments'],
    advantages: ['Git-based auto deploys', 'Global edge network', 'Generous free tier'],
    learnMoreHref: 'https://vercel.com',
  },
  {
    id: 'firebase-hosting',
    icon: Flame,
    name: 'Firebase Hosting',
    accent: 'signal',
    description:
      'Fast static hosting that pairs naturally with Firebase\u2019s managed backend services when a project grows.',
    bestUseCases: ['SPAs backed by Firebase', 'Apps needing auth/DB later', 'Google Cloud stacks'],
    advantages: ['Free SSL out of the box', 'CDN-backed hosting', 'One CLI for hosting & functions'],
    learnMoreHref: 'https://firebase.google.com/docs/hosting',
  },
  {
    id: 'netlify',
    icon: Waves,
    name: 'Netlify',
    accent: 'pulse',
    description:
      'Fast static and JAMstack hosting with a simple, git-based workflow and built-in form handling.',
    bestUseCases: ['Static sites & JAMstack', 'Marketing sites', 'Content-driven projects'],
    advantages: ['Simple git-based deploys', 'Built-in forms & redirects', 'Easy rollback per deploy'],
    learnMoreHref: 'https://www.netlify.com',
  },
  {
    id: 'hostinger',
    icon: Box,
    name: 'Hostinger',
    accent: 'online',
    description:
      'Traditional web hosting with cPanel-style control \u2014 a familiar, budget-friendly option for classic stacks.',
    bestUseCases: ['WordPress / PHP sites', 'Budget-conscious projects', 'Full control over a server'],
    advantages: ['Low-cost entry plans', 'Familiar hosting control panel', 'Email hosting included'],
    learnMoreHref: 'https://www.hostinger.com',
  },
  {
    id: 'cloudflare-pages',
    icon: Cloud,
    name: 'Cloudflare Pages',
    accent: 'pulse',
    description:
      'Static hosting on Cloudflare\u2019s global network, with edge functions available when you need more than static.',
    bestUseCases: ['Global, low-latency sites', 'Static + edge functions', 'Projects already on Cloudflare'],
    advantages: ['Massive global CDN', 'Unlimited bandwidth on free tier', 'Built-in DDoS protection'],
    learnMoreHref: 'https://pages.cloudflare.com',
  },
]
