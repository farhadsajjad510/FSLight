export interface FAQItem {
  id: string
  question: string
  answer: string
}

export const AI_CODING_FAQS: FAQItem[] = [
  {
    id: 'which-ai-best',
    question: 'Which AI is best for coding?',
    answer:
      'There isn\u2019t one universal winner \u2014 it depends on the task. Claude tends to shine on larger, multi-step codebases; ChatGPT has the broadest plugin ecosystem; Gemini fits naturally if you\u2019re already in the Google stack. Compare the cards above and pick based on the work in front of you.',
  },
  {
    id: 'ai-replace-developers',
    question: 'Can AI replace developers?',
    answer:
      'No \u2014 AI is a tool that speeds up parts of the process, not a replacement for engineering judgment. Someone still needs to define the problem, review the output, test it, and take responsibility for what ships.',
  },
  {
    id: 'use-ai-safely',
    question: 'How should I use AI safely?',
    answer:
      'Never paste secrets or sensitive data into a prompt, review every suggestion before merging it, run tests, and keep security in mind \u2014 especially around auth, input handling, and dependencies.',
  },
  {
    id: 'beginners-which-ai',
    question: 'Which AI should beginners use?',
    answer:
      'Any of the major assistants work well to start \u2014 the more important habit is learning to read and understand the code they generate, rather than copying it blindly. Start small, ask the AI to explain its own output, and build from there.',
  },
]
