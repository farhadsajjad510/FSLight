import type { ProjectCard } from '@/types'

export const FEATURED_PROJECTS: ProjectCard[] = [
  {
    id: 'live-attendance',
    title: 'Live Attendance',
    summary:
      'A real-time attendance tracking system built to replace manual sign-in sheets with a fast, reliable digital flow.',
    stack: ['React', 'TypeScript', 'Real-time DB'],
    status: 'in-progress',
  },
  {
    id: 'farhadoo-ai',
    title: 'Farhadoo AI',
    summary:
      'FarhadAIStudio\u2019s own AI assistant, purpose-built around the workflows this platform is designed for.',
    stack: ['AI/ML', 'TypeScript', 'API Design'],
    status: 'concept',
  },
]
