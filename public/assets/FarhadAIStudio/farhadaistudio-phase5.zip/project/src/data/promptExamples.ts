import type { LucideIcon } from 'lucide-react'
import { Atom, Flame, FileType2, Palette, Bug, LayoutTemplate } from 'lucide-react'

export interface PromptExample {
  id: string
  icon: LucideIcon
  category: string
  prompt: string
}

/**
 * Placeholder prompt starters shown with a copy-to-clipboard action.
 * These are illustrative only \u2014 no AI call is made from this page.
 */
export const PROMPT_EXAMPLES: PromptExample[] = [
  {
    id: 'react',
    icon: Atom,
    category: 'React',
    prompt:
      'Create a reusable React component for [feature]. Use TypeScript, keep props minimal, and explain any state decisions.',
  },
  {
    id: 'firebase',
    icon: Flame,
    category: 'Firebase',
    prompt:
      'Write a Firestore query that fetches [data] for the current user, with proper security-rule considerations noted.',
  },
  {
    id: 'typescript',
    icon: FileType2,
    category: 'TypeScript',
    prompt:
      'Add strict TypeScript types for this data shape: [paste shape]. Flag anywhere \u201cany\u201d would otherwise sneak in.',
  },
  {
    id: 'tailwind',
    icon: Palette,
    category: 'Tailwind CSS',
    prompt:
      'Style this component with Tailwind CSS for a [style, e.g. minimal dark] look. Keep it responsive and mobile-first.',
  },
  {
    id: 'debugging',
    icon: Bug,
    category: 'Debugging',
    prompt:
      'Here\u2019s an error and the relevant code: [paste]. Explain the root cause before suggesting a fix.',
  },
  {
    id: 'ui-design',
    icon: LayoutTemplate,
    category: 'UI Design',
    prompt:
      'Suggest a clean layout for [screen/page]. Prioritize hierarchy, spacing, and mobile usability over decoration.',
  },
]
