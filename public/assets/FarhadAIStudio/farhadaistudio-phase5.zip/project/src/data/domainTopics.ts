import type { LucideIcon } from 'lucide-react'
import { Globe2, Target, PenTool, ShieldCheck, Network } from 'lucide-react'

export interface DomainTopic {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

/**
 * Educational-only domain topics for the Domain & Hosting page. No
 * registrar is wired up here \u2014 this is the "understand it first"
 * layer before someone goes and buys a domain elsewhere.
 */
export const DOMAIN_TOPICS: DomainTopic[] = [
  {
    id: 'what-is-a-domain',
    icon: Globe2,
    title: 'What is a Domain?',
    description:
      'A domain is the human-readable address people type to reach your project \u2014 it points to your server so visitors never see a raw IP address.',
  },
  {
    id: 'why-every-project-needs-one',
    icon: Target,
    title: 'Why Every Project Needs a Domain',
    description:
      'A domain makes a project feel real and trustworthy, gives you a stable address as hosting changes, and is essential for branding, email, and SEO.',
  },
  {
    id: 'choosing-the-right-name',
    icon: PenTool,
    title: 'Choosing the Right Domain Name',
    description:
      'Keep it short, easy to spell, and easy to say out loud. Avoid hyphens and numbers where possible, and make sure it matches your brand, not just what\u2019s available.',
  },
  {
    id: 'domain-security-basics',
    icon: ShieldCheck,
    title: 'Domain Security Basics',
    description:
      'Enable WHOIS privacy, turn on registrar/transfer locking, use a strong unique password with two-factor auth, and keep renewal auto-pay on so you never lose it.',
  },
  {
    id: 'dns-introduction',
    icon: Network,
    title: 'DNS Introduction',
    description:
      'DNS translates your domain into the technical details servers need \u2014 A records point to an IP, CNAME records point to another domain, and MX records route email.',
  },
]
