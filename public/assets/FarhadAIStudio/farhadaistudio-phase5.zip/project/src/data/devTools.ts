import type { LucideIcon } from 'lucide-react'
import { Code2, GitBranch, Github, Flame, Triangle, Chrome } from 'lucide-react'

export interface DevTool {
  id: string
  icon: LucideIcon
  label: string
}

/** Placeholder icon + label chips \u2014 no accounts or integrations. */
export const RECOMMENDED_TOOLS: DevTool[] = [
  { id: 'vscode', icon: Code2, label: 'VS Code' },
  { id: 'git', icon: GitBranch, label: 'Git' },
  { id: 'github', icon: Github, label: 'GitHub' },
  { id: 'firebase', icon: Flame, label: 'Firebase' },
  { id: 'vercel', icon: Triangle, label: 'Vercel' },
  { id: 'chrome-devtools', icon: Chrome, label: 'Chrome DevTools' },
]
