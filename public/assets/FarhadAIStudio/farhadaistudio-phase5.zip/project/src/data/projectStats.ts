import type { LucideIcon } from 'lucide-react'
import { FolderGit2, Layers, Clock, Rocket } from 'lucide-react'

export interface ProjectStat {
  id: string
  icon: LucideIcon
  value: number
  suffix?: string
  label: string
}

/** Placeholder values \u2014 update as real numbers become meaningful. */
export const PROJECT_STATS: ProjectStat[] = [
  { id: 'active-projects', icon: FolderGit2, value: 2, label: 'Active Projects' },
  { id: 'technologies-used', icon: Layers, value: 8, suffix: '+', label: 'Technologies Used' },
  { id: 'development-hours', icon: Clock, value: 500, suffix: '+', label: 'Development Hours' },
  { id: 'future-products', icon: Rocket, value: 5, suffix: '+', label: 'Future Products' },
]
