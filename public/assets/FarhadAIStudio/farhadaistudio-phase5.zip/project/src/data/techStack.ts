import type { LucideIcon } from 'lucide-react'
import { Atom, FileType2, Palette, Flame, Zap, GitBranch, Github, Sparkles } from 'lucide-react'

export interface TechStackItem {
  id: string
  icon: LucideIcon
  label: string
  future?: boolean
}

export const TECH_STACK: TechStackItem[] = [
  { id: 'react', icon: Atom, label: 'React' },
  { id: 'typescript', icon: FileType2, label: 'TypeScript' },
  { id: 'tailwind', icon: Palette, label: 'Tailwind CSS' },
  { id: 'firebase', icon: Flame, label: 'Firebase' },
  { id: 'vite', icon: Zap, label: 'Vite' },
  { id: 'git', icon: GitBranch, label: 'Git' },
  { id: 'github', icon: Github, label: 'GitHub' },
  { id: 'ai-apis', icon: Sparkles, label: 'AI APIs', future: true },
]
