import type { LucideIcon } from 'lucide-react'
import { MessageSquareText, ScanEye, TestTubeDiagonal, BrainCircuit, ShieldCheck, GitBranch } from 'lucide-react'

export interface BestPractice {
  id: string
  icon: LucideIcon
  title: string
  description: string
}

export const BEST_PRACTICES: BestPractice[] = [
  {
    id: 'clear-prompts',
    icon: MessageSquareText,
    title: 'Write Clear Prompts',
    description: 'Give context, constraints, and the actual goal \u2014 vague prompts get vague code.',
  },
  {
    id: 'review-output',
    icon: ScanEye,
    title: 'Review AI Output',
    description: 'Treat every response as a first draft. Read it line by line before trusting it.',
  },
  {
    id: 'test-everything',
    icon: TestTubeDiagonal,
    title: 'Test Everything',
    description: 'AI-generated code still needs to be run, tested, and verified like any other code.',
  },
  {
    id: 'understand-first',
    icon: BrainCircuit,
    title: 'Never Copy Without Understanding',
    description: 'If you can\u2019t explain what a block of code does, don\u2019t ship it yet.',
  },
  {
    id: 'keep-secure',
    icon: ShieldCheck,
    title: 'Keep Code Secure',
    description: 'Watch for hardcoded secrets, unsafe inputs, and dependencies AI suggests without checking them.',
  },
  {
    id: 'version-control',
    icon: GitBranch,
    title: 'Version Control with Git',
    description: 'Commit often so AI-assisted changes are always easy to review, compare, and roll back.',
  },
]
