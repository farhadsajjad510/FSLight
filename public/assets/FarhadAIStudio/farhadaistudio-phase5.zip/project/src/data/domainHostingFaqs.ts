import type { FAQItem } from './faqs'

export const DOMAIN_HOSTING_FAQS: FAQItem[] = [
  {
    id: 'best-hosting-for-beginners',
    question: 'Which hosting is best for beginners?',
    answer:
      'Vercel and Netlify are the easiest starting points \u2014 connect a git repo and deploys happen automatically, with generous free tiers and no server config required.',
  },
  {
    id: 'domain-vs-hosting',
    question: 'What is the difference between a domain and hosting?',
    answer:
      'A domain is the address people type to find your site (like farhadaistudio.com). Hosting is where the actual files and code live. You need both \u2014 the domain just points to the hosting.',
  },
  {
    id: 'deploy-for-free',
    question: 'Can I deploy for free?',
    answer:
      'Yes \u2014 Vercel, Netlify, Firebase Hosting, and Cloudflare Pages all offer solid free tiers that cover most personal and early-stage projects.',
  },
  {
    id: 'when-buy-custom-domain',
    question: 'When should I buy a custom domain?',
    answer:
      'Once your project is stable enough to share \u2014 a custom domain adds trust and professionalism, but there\u2019s no need to buy one before you have something worth pointing it at.',
  },
]
