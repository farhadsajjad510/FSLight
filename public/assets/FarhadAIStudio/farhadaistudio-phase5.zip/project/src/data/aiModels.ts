export interface AIModel {
  id: string
  name: string
  maker: string
  accent: 'signal' | 'pulse' | 'online'
  intro: string
  bestUseCases: string[]
  strengths: string[]
  limitations: string[]
  learnMoreHref: string
}

/**
 * Informational only — no pricing, no API keys, no integration. Each
 * entry backs a card on the AI Coding page so visitors can compare
 * assistants before choosing one to work with.
 */
export const AI_MODELS: AIModel[] = [
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    maker: 'OpenAI',
    accent: 'online',
    intro:
      'A versatile, widely-adopted assistant with a huge ecosystem of plugins, extensions, and integrations built around it.',
    bestUseCases: [
      'General-purpose coding help',
      'Quick prototyping & scripts',
      'Explaining unfamiliar code',
      'Brainstorming architecture',
    ],
    strengths: [
      'Huge plugin & tooling ecosystem',
      'Fast, conversational responses',
      'Strong general knowledge base',
      'Wide programming-language support',
    ],
    limitations: [
      'Can lose precision on very large codebases',
      'Niche or brand-new APIs may need double-checking',
      'Context window varies by plan',
    ],
    learnMoreHref: 'https://chat.openai.com',
  },
  {
    id: 'claude',
    name: 'Claude',
    maker: 'Anthropic',
    accent: 'signal',
    intro:
      'A careful, context-aware coding partner built for reasoning through larger codebases and multi-step engineering work.',
    bestUseCases: [
      'Multi-file / agentic coding',
      'Refactoring large codebases',
      'Careful code review',
      'Detailed technical writing',
    ],
    strengths: [
      'Long context window',
      'Careful, step-by-step reasoning',
      'Strong instruction-following',
      'Explains trade-offs clearly',
    ],
    limitations: [
      'Can feel slower for very short answers',
      'Smaller third-party plugin ecosystem',
      'Newer platform footprint than some competitors',
    ],
    learnMoreHref: 'https://claude.ai',
  },
  {
    id: 'gemini',
    name: 'Gemini',
    maker: 'Google',
    accent: 'pulse',
    intro:
      'Deeply integrated with Google\u2019s tooling and multimodal input \u2014 a strong pick when your stack already lives in that ecosystem.',
    bestUseCases: [
      'Google Cloud & Firebase workflows',
      'Multimodal input (images, docs)',
      'Fast lookups & research',
      'Working inside Google Workspace',
    ],
    strengths: [
      'Native Google ecosystem integration',
      'Multimodal understanding',
      'Fast iteration speed',
      'Tight Firebase / Cloud tie-in',
    ],
    limitations: [
      'Best results tied to the Google ecosystem',
      'Reasoning depth varies by task type',
      'Still maturing at complex agentic coding',
    ],
    learnMoreHref: 'https://gemini.google.com',
  },
]
