export const SITE = {
  name: 'FarhadAIStudio',
  shortName: 'FarhadAI',
  tagline: 'AI Developer Platform',
  description:
    'Discover AI coding tools, learn deployment, explore projects, and connect for development services.',
  url: 'https://farhadaistudio.com',
  email: 'hello@farhadaistudio.com',
  social: {
    github: 'https://github.com/farhadaistudio',
    twitter: 'https://twitter.com/farhadaistudio',
    linkedin: 'https://linkedin.com/company/farhadaistudio',
  },
} as const
