import SEO from '@/components/SEO'
import Intro from '@/sections/domain-hosting/Intro'
import DomainEducation from '@/sections/domain-hosting/DomainEducation'
import HostingPlatforms from '@/sections/domain-hosting/HostingPlatforms'
import DeploymentGuides from '@/sections/domain-hosting/DeploymentGuides'
import LaunchChecklist from '@/sections/domain-hosting/LaunchChecklist'
import RecommendedTools from '@/sections/domain-hosting/RecommendedTools'
import FAQ from '@/sections/domain-hosting/FAQ'
import CTA from '@/sections/domain-hosting/CTA'

export default function DomainHosting() {
  return (
    <>
      <SEO
        title="Domain & Hosting"
        description="Learn how to choose a domain, compare hosting platforms, and deploy your project with confidence."
        path="/domain-hosting"
      />
      <Intro />
      <DomainEducation />
      <HostingPlatforms />
      <DeploymentGuides />
      <LaunchChecklist />
      <RecommendedTools />
      <FAQ />
      <CTA />
    </>
  )
}
