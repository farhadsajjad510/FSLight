import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import Container from '@/components/Container'

export default function Terms() {
  return (
    <>
      <SEO
        title="Terms of Service"
        description="Terms of use for FarhadAIStudio — placeholder for Phase 1/2."
        path="/terms"
      />
      <PageHero
        eyebrow="legal"
        title="Terms of Service"
        description="This is a placeholder page. Full terms of use will be published alongside the platform's first real services."
      />
      <Container className="max-w-3xl py-16 sm:py-20">
        <p className="text-sm text-text-muted">
          FarhadAIStudio is currently an informational platform with no accounts, transactions,
          or user-generated content. Formal terms of service will be added once those features
          ship.
        </p>
      </Container>
    </>
  )
}
