import { ArrowLeft } from 'lucide-react'
import SEO from '@/components/SEO'
import Container from '@/components/Container'
import Button from '@/components/Button'

export default function NotFound() {
  return (
    <>
      <SEO title="Page not found" path="/404" />
      <Container className="flex min-h-[70vh] flex-col items-center justify-center gap-5 py-20 text-center">
        <span className="font-mono text-xs text-signal">// error</span>
        <h1 className="font-mono text-6xl sm:text-7xl font-semibold text-text">404</h1>
        <p className="max-w-sm text-text-muted">
          This route doesn&apos;t resolve to anything. It may have moved, or it never existed.
        </p>
        <Button to="/" variant="secondary" icon={<ArrowLeft size={16} />} iconPosition="left">
          Back to home
        </Button>
      </Container>
    </>
  )
}
