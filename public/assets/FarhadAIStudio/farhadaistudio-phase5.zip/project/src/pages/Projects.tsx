import SEO from '@/components/SEO'
import Intro from '@/sections/projects/Intro'
import LiveAttendance from '@/sections/projects/LiveAttendance'
import FarhadooAI from '@/sections/projects/FarhadooAI'
import FutureProjects from '@/sections/projects/FutureProjects'
import TechStack from '@/sections/projects/TechStack'
import DevelopmentTimeline from '@/sections/projects/DevelopmentTimeline'
import ProjectStats from '@/sections/projects/ProjectStats'
import CTA from '@/sections/projects/CTA'

export default function Projects() {
  return (
    <>
      <SEO
        title="Projects"
        description="A showcase of FarhadAIStudio products — shipped, in progress, and planned."
        path="/projects"
      />
      <Intro />
      <LiveAttendance />
      <FarhadooAI />
      <FutureProjects />
      <TechStack />
      <DevelopmentTimeline />
      <ProjectStats />
      <CTA />
    </>
  )
}
