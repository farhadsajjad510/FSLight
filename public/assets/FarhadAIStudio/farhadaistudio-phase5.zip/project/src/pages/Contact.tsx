import { useState, type FormEvent } from 'react'
import { Mail, Github, Twitter, Linkedin, ArrowRight } from 'lucide-react'
import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import Container from '@/components/Container'
import Button from '@/components/Button'
import { SITE } from '@/constants/site'

const CHANNELS = [
  { label: SITE.email, href: `mailto:${SITE.email}`, icon: Mail },
  { label: 'GitHub', href: SITE.social.github, icon: Github },
  { label: 'Twitter', href: SITE.social.twitter, icon: Twitter },
  { label: 'LinkedIn', href: SITE.social.linkedin, icon: Linkedin },
]

/**
 * Phase 1 has no backend, so the form composes a mailto: link from the
 * fields rather than submitting anywhere — the UI is fully built and
 * ready to be wired to a real endpoint in a later phase.
 */
export default function Contact() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const subject = encodeURIComponent(`Project inquiry from ${name || 'website visitor'}`)
    const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`)
    window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`
  }

  return (
    <>
      <SEO
        title="Contact"
        description="Connect with FarhadAIStudio for AI development services and questions."
        path="/contact"
      />
      <PageHero
        eyebrow="say hello"
        title="Let's talk about what you're building"
        description="Send a message and we'll get back to you — or reach out directly through any channel below."
      />

      <Container className="grid grid-cols-1 gap-10 py-16 sm:py-20 lg:grid-cols-5 lg:gap-14">
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-5 rounded-[var(--radius-lg)] border border-border bg-panel p-6 sm:p-8 lg:col-span-3"
        >
          <div className="flex flex-col gap-2">
            <label htmlFor="name" className="font-mono text-xs text-text-muted">
              name
            </label>
            <input
              id="name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="rounded-[var(--radius-sm)] border border-border bg-panel-raised px-4 py-3 text-sm text-text placeholder:text-text-faint outline-none focus-visible:border-signal"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label htmlFor="email" className="font-mono text-xs text-text-muted">
              email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="rounded-[var(--radius-sm)] border border-border bg-panel-raised px-4 py-3 text-sm text-text placeholder:text-text-faint outline-none focus-visible:border-signal"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label htmlFor="message" className="font-mono text-xs text-text-muted">
              message
            </label>
            <textarea
              id="message"
              required
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us about your project..."
              className="resize-none rounded-[var(--radius-sm)] border border-border bg-panel-raised px-4 py-3 text-sm text-text placeholder:text-text-faint outline-none focus-visible:border-signal"
            />
          </div>

          <Button type="submit" icon={<ArrowRight size={16} />} className="mt-2 w-fit">
            Send message
          </Button>
        </form>

        <div className="flex flex-col gap-4 lg:col-span-2">
          <span className="font-mono text-xs text-text-faint">// or reach out directly</span>
          {CHANNELS.map(({ label, href, icon: Icon }) => (
            <a
              key={label}
              href={href}
              target={href.startsWith('mailto') ? undefined : '_blank'}
              rel={href.startsWith('mailto') ? undefined : 'noreferrer'}
              className="flex items-center gap-3 rounded-[var(--radius-md)] border border-border bg-panel px-4 py-3.5 text-sm text-text-muted transition-colors hover:border-signal/40 hover:text-text"
            >
              <Icon size={17} className="text-signal" />
              {label}
            </a>
          ))}
        </div>
      </Container>
    </>
  )
}
