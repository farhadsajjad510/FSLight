import SEO from '@/components/SEO'
import Hero from '@/sections/home/Hero'
import WhatIs from '@/sections/home/WhatIs'
import AICodingSection from '@/sections/home/AICodingSection'
import DomainServices from '@/sections/home/DomainServices'
import HostingDeployment from '@/sections/home/HostingDeployment'
import FeaturedProjects from '@/sections/home/FeaturedProjects'
import WhyChooseUs from '@/sections/home/WhyChooseUs'
import CTA from '@/sections/home/CTA'

export default function Home() {
  return (
    <>
      <SEO path="/" />
      <Hero />
      <WhatIs />
      <AICodingSection />
      <DomainServices />
      <HostingDeployment />
      <FeaturedProjects />
      <WhyChooseUs />
      <CTA />
    </>
  )
}
