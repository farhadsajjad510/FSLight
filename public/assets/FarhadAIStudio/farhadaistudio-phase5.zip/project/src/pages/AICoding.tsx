import SEO from '@/components/SEO'
import Intro from '@/sections/ai-coding/Intro'
import FeaturedModels from '@/sections/ai-coding/FeaturedModels'
import FaradooSpotlight from '@/sections/ai-coding/FaradooSpotlight'
import Workflow from '@/sections/ai-coding/Workflow'
import BestPractices from '@/sections/ai-coding/BestPractices'
import PromptExamples from '@/sections/ai-coding/PromptExamples'
import FAQ from '@/sections/ai-coding/FAQ'
import CTA from '@/sections/ai-coding/CTA'

export default function AICoding() {
  return (
    <>
      <SEO
        title="AI Coding"
        description="Discover AI coding assistants, learn a responsible AI-assisted development workflow, and see what's next from FarhadAIStudio."
        path="/ai-coding"
      />
      <Intro />
      <FeaturedModels />
      <FaradooSpotlight />
      <Workflow />
      <BestPractices />
      <PromptExamples />
      <FAQ />
      <CTA />
    </>
  )
}
