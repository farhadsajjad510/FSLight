import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import Container from '@/components/Container'

export default function Privacy() {
  return (
    <>
      <SEO
        title="Privacy Policy"
        description="How FarhadAIStudio handles data — placeholder for Phase 1/2."
        path="/privacy"
      />
      <PageHero
        eyebrow="legal"
        title="Privacy Policy"
        description="This is a placeholder page. A full privacy policy will be published as the platform's data practices are finalized."
      />
      <Container className="max-w-3xl py-16 sm:py-20">
        <p className="text-sm text-text-muted">
          FarhadAIStudio does not yet collect, store, or process personal data — this version of
          the platform has no accounts, forms that submit anywhere, or backend services. A
          complete privacy policy will replace this page once those systems exist.
        </p>
      </Container>
    </>
  )
}
