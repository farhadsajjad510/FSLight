import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import PlaceholderGrid from '@/components/PlaceholderGrid'

export default function Resources() {
  return (
    <>
      <SEO
        title="Resources"
        description="Guides, references, and checklists for AI-assisted development."
        path="/resources"
      />
      <PageHero
        eyebrow="knowledge base"
        title="Guides worth bookmarking"
        description="Practical references and checklists for working with AI coding tools day to day — written as they're used, not as marketing."
      />
      <PlaceholderGrid note="guides populate in phase 2" />
    </>
  )
}
