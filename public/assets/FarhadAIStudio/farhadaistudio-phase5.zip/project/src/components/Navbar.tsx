import { useEffect, useState } from 'react'
import { NavLink as RouterNavLink } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import Container from './Container'
import Logo from './Logo'
import Button from './Button'
import { NAV_LINKS } from '@/data/navigation'
import { cn } from '@/utils/cn'

/**
 * Responsive top navigation. Desktop shows an inline link row; below the
 * `lg` breakpoint it collapses into a full-screen mono-styled menu.
 */
export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <header
      className={cn(
        'sticky top-0 z-50 transition-colors duration-200',
        scrolled ? 'bg-ink/90 backdrop-blur-md border-b border-border' : 'bg-transparent',
      )}
    >
      <Container>
        <nav className="flex h-16 items-center justify-between" aria-label="Primary">
          <Logo />

          <ul className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.path}>
                <RouterNavLink
                  to={link.path}
                  end={link.path === '/'}
                  className={({ isActive }) =>
                    cn(
                      'block rounded-[var(--radius-sm)] px-3.5 py-2 font-mono text-sm transition-colors',
                      isActive
                        ? 'text-signal'
                        : 'text-text-muted hover:text-text',
                    )
                  }
                >
                  {link.label}
                </RouterNavLink>
              </li>
            ))}
          </ul>

          <div className="hidden lg:block">
            <Button to="/contact" size="sm">
              Get in touch
            </Button>
          </div>

          <button
            type="button"
            className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-[var(--radius-sm)] text-text hover:bg-panel-raised"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </nav>
      </Container>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="lg:hidden overflow-hidden border-t border-border bg-ink"
          >
            <Container>
              <ul className="flex flex-col py-4">
                {NAV_LINKS.map((link) => (
                  <li key={link.path}>
                    <RouterNavLink
                      to={link.path}
                      end={link.path === '/'}
                      onClick={() => setOpen(false)}
                      className={({ isActive }) =>
                        cn(
                          'block rounded-[var(--radius-sm)] px-2 py-3 font-mono text-base transition-colors',
                          isActive ? 'text-signal' : 'text-text-muted',
                        )
                      }
                    >
                      {link.label}
                    </RouterNavLink>
                  </li>
                ))}
              </ul>
              <div className="pb-6">
                <Button to="/contact" className="w-full" onClick={() => setOpen(false)}>
                  Get in touch
                </Button>
              </div>
            </Container>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
