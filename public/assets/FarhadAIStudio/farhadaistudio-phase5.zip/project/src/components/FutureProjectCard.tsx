import type { FutureProject } from '@/data/futureProjects'
import Badge from './Badge'

interface FutureProjectCardProps {
  project: FutureProject
}

export default function FutureProjectCard({ project }: FutureProjectCardProps) {
  return (
    <div className="flex flex-col gap-4 rounded-[var(--radius-lg)] border border-dashed border-border bg-panel/50 p-6 transition-colors hover:border-signal/40">
      <div className="flex items-start justify-between gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-text-faint">
          <project.icon size={18} />
        </div>
        <Badge tone="pulse">coming soon</Badge>
      </div>

      <h3 className="text-base font-semibold text-text">{project.title}</h3>
      <p className="text-sm text-text-muted">{project.description}</p>
    </div>
  )
}
