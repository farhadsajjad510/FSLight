import { ArrowUpRight, CheckCircle2, AlertTriangle } from 'lucide-react'
import type { AIModel } from '@/data/aiModels'
import { cn } from '@/utils/cn'
import Badge from './Badge'
import Button from './Button'

interface AIModelCardProps {
  model: AIModel
}

const ACCENT_STYLES: Record<AIModel['accent'], string> = {
  signal: 'bg-signal-soft text-signal border-signal/30',
  pulse: 'bg-pulse-soft text-pulse border-pulse/30',
  online: 'bg-panel-raised text-online border-online/30',
}

/**
 * Detailed feature card for the AI Coding page's "Featured AI Models"
 * section — intro, best use cases, strengths, and limitations for
 * one assistant. Informational only, no pricing, no API calls.
 */
export default function AIModelCard({ model }: AIModelCardProps) {
  return (
    <div className="flex flex-col gap-6 rounded-[var(--radius-lg)] border border-border bg-panel p-6 sm:p-7 transition-colors hover:border-signal/40">
      <div className="flex items-center gap-4">
        <div
          className={cn(
            'flex h-12 w-12 shrink-0 items-center justify-center rounded-[var(--radius-md)] border font-display text-lg font-semibold',
            ACCENT_STYLES[model.accent],
          )}
          aria-hidden="true"
        >
          {model.name.charAt(0)}
        </div>
        <div>
          <p className="font-mono text-xs text-text-faint">{model.maker}</p>
          <h3 className="text-xl font-semibold text-text">{model.name}</h3>
        </div>
      </div>

      <p className="text-sm text-text-muted">{model.intro}</p>

      <div className="flex flex-col gap-4">
        <div>
          <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">
            best use cases
          </p>
          <div className="flex flex-wrap gap-2">
            {model.bestUseCases.map((useCase) => (
              <Badge key={useCase} tone="muted">
                {useCase}
              </Badge>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">strengths</p>
          <ul className="flex flex-col gap-1.5">
            {model.strengths.map((strength) => (
              <li key={strength} className="flex items-start gap-2 text-sm text-text-muted">
                <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-online" />
                {strength}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">limitations</p>
          <ul className="flex flex-col gap-1.5">
            {model.limitations.map((limitation) => (
              <li key={limitation} className="flex items-start gap-2 text-sm text-text-muted">
                <AlertTriangle size={14} className="mt-0.5 shrink-0 text-signal" />
                {limitation}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <Button
        href={model.learnMoreHref}
        variant="secondary"
        size="sm"
        icon={<ArrowUpRight size={14} />}
        className="mt-auto self-start"
        target="_blank"
        rel="noopener noreferrer"
      >
        Learn more
      </Button>
    </div>
  )
}
