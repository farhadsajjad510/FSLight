import { ArrowUpRight, CheckCircle2 } from 'lucide-react'
import type { HostingPlatformDetail } from '@/data/hostingPlatformsDetailed'
import { cn } from '@/utils/cn'
import Badge from './Badge'
import Button from './Button'

interface HostingPlatformCardProps {
  platform: HostingPlatformDetail
}

const ACCENT_STYLES: Record<HostingPlatformDetail['accent'], string> = {
  signal: 'bg-signal-soft text-signal border-signal/30',
  pulse: 'bg-pulse-soft text-pulse border-pulse/30',
  online: 'bg-panel-raised text-online border-online/30',
}

/**
 * Detailed feature card for the Domain & Hosting page's platform
 * comparison section — description, best use cases, advantages, and
 * a Learn More link. No signup or API call happens here.
 */
export default function HostingPlatformCard({ platform }: HostingPlatformCardProps) {
  return (
    <div className="flex flex-col gap-5 rounded-[var(--radius-lg)] border border-border bg-panel p-6 transition-colors hover:border-signal/40">
      <div className="flex items-center gap-3">
        <div
          className={cn(
            'flex h-11 w-11 shrink-0 items-center justify-center rounded-[var(--radius-md)] border',
            ACCENT_STYLES[platform.accent],
          )}
          aria-hidden="true"
        >
          <platform.icon size={20} />
        </div>
        <h3 className="text-lg font-semibold text-text">{platform.name}</h3>
      </div>

      <p className="text-sm text-text-muted">{platform.description}</p>

      <div>
        <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">best use cases</p>
        <div className="flex flex-wrap gap-2">
          {platform.bestUseCases.map((useCase) => (
            <Badge key={useCase} tone="muted">
              {useCase}
            </Badge>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">advantages</p>
        <ul className="flex flex-col gap-1.5">
          {platform.advantages.map((advantage) => (
            <li key={advantage} className="flex items-start gap-2 text-sm text-text-muted">
              <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-online" />
              {advantage}
            </li>
          ))}
        </ul>
      </div>

      <Button
        href={platform.learnMoreHref}
        variant="secondary"
        size="sm"
        icon={<ArrowUpRight size={14} />}
        className="mt-auto self-start"
        target="_blank"
        rel="noopener noreferrer"
      >
        Learn more
      </Button>
    </div>
  )
}
