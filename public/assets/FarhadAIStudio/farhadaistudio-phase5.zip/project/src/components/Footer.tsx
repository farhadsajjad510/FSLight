import { Link } from 'react-router-dom'
import { Github, Twitter, Linkedin } from 'lucide-react'
import Container from './Container'
import Logo from './Logo'
import { NAV_LINKS } from '@/data/navigation'
import { SITE } from '@/constants/site'

const LEGAL_LINKS = [
  { label: 'Privacy Policy', path: '/privacy' },
  { label: 'Terms', path: '/terms' },
]

const SOCIALS = [
  { label: 'GitHub', href: SITE.social.github, icon: Github },
  { label: 'Twitter', href: SITE.social.twitter, icon: Twitter },
  { label: 'LinkedIn', href: SITE.social.linkedin, icon: Linkedin },
]

export default function Footer() {
  return (
    <footer className="border-t border-border bg-panel">
      <Container>
        <div className="grid grid-cols-1 gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col gap-4 sm:col-span-2 lg:col-span-1">
            <Logo />
            <p className="text-sm text-text-muted max-w-xs">{SITE.description}</p>
          </div>

          <div className="flex flex-col gap-3">
            <span className="font-mono text-xs text-text-faint">// navigate</span>
            <ul className="flex flex-col gap-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-text-muted hover:text-signal transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col gap-3">
            <span className="font-mono text-xs text-text-faint">// connect</span>
            <ul className="flex flex-col gap-2.5">
              <li>
                <a
                  href={`mailto:${SITE.email}`}
                  className="text-sm text-text-muted hover:text-signal transition-colors"
                >
                  {SITE.email}
                </a>
              </li>
            </ul>
            <div className="flex items-center gap-3 pt-1">
              {SOCIALS.map(({ label, href, icon: Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-[var(--radius-sm)] border border-border text-text-muted hover:text-signal hover:border-signal/50 transition-colors"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <span className="font-mono text-xs text-text-faint">// status</span>
            <div className="flex items-center gap-2 text-sm text-text-muted">
              <span className="h-1.5 w-1.5 rounded-full bg-online" aria-hidden="true" />
              All systems operational
            </div>
          </div>
        </div>

        <div className="flex flex-col-reverse items-center gap-3 border-t border-border py-6 sm:flex-row sm:justify-between">
          <p className="font-mono text-xs text-text-faint">
            © {new Date().getFullYear()} {SITE.name}. All rights reserved.
          </p>
          <ul className="flex items-center gap-5">
            {LEGAL_LINKS.map((link) => (
              <li key={link.path}>
                <Link
                  to={link.path}
                  className="font-mono text-xs text-text-faint hover:text-text-muted transition-colors"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </footer>
  )
}
