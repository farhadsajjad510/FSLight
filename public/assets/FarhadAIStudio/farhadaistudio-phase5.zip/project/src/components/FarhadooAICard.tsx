import { Bell, Sparkles } from 'lucide-react'
import type { FarhadooAIProject } from '@/data/farhadooAI'
import Badge from './Badge'
import Button from './Button'

interface FarhadooAICardProps {
  project: FarhadooAIProject
}

/**
 * Farhadoo AI has no shipped functionality yet — every section here
 * is framed as a stated intention, and the primary action is a
 * disabled "coming soon" button rather than anything functional.
 */
export default function FarhadooAICard({ project }: FarhadooAICardProps) {
  return (
    <div className="relative overflow-hidden rounded-[var(--radius-xl)] border border-signal/30 bg-panel p-7 sm:p-10">
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_100%_0%,rgba(245,166,35,0.12),transparent)]"
        aria-hidden="true"
      />

      <div className="relative flex flex-col gap-6 lg:flex-row lg:justify-between">
        <div className="flex flex-col gap-5 lg:max-w-md">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="pulse">coming soon</Badge>
            <Badge tone="muted">{project.tagline}</Badge>
          </div>

          <div>
            <p className="font-mono text-xs text-text-faint">FarhadAIStudio product</p>
            <h3 className="mt-1 text-2xl sm:text-3xl font-semibold text-text">Farhadoo AI</h3>
          </div>

          <p className="text-sm text-text-muted">{project.futureVision}</p>

          <div>
            <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">
              planned features
            </p>
            <div className="flex flex-wrap gap-2">
              {project.plannedFeatures.map((feature) => (
                <Badge key={feature} tone="muted">
                  {feature}
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">
              technology stack (planned)
            </p>
            <div className="flex flex-wrap gap-2">
              {project.techStackPlanned.map((tech) => (
                <Badge key={tech} tone="muted">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>

          <Button disabled variant="secondary" icon={<Bell size={16} />} className="mt-2 w-fit">
            Notify Me — Coming Soon
          </Button>
        </div>

        <div className="flex flex-col gap-4 lg:w-72 lg:shrink-0">
          <p className="font-mono text-[11px] tracking-wide text-text-faint">
            development roadmap
          </p>
          <div className="flex flex-col gap-4 border-l border-border pl-5">
            {project.roadmap.map((step) => (
              <div key={step.id} className="relative">
                <span className="absolute -left-[25px] top-1 h-2.5 w-2.5 rounded-full border border-signal bg-panel" />
                <p className="font-mono text-[11px] text-signal">{step.phase}</p>
                <p className="mt-0.5 text-sm text-text-muted">{step.label}</p>
              </div>
            ))}
            <div className="relative flex items-center gap-2 text-text-faint">
              <span className="absolute -left-[25px] top-1 h-2.5 w-2.5 rounded-full border border-dashed border-text-faint bg-panel" />
              <Sparkles size={13} />
              <p className="text-xs">what&apos;s next, still taking shape</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
