import type { ComponentType, ReactNode } from 'react'
import { cn } from '@/utils/cn'

interface IconCardProps {
  icon: ComponentType<{ size?: number | string; className?: string }>
  title: string
  description: string
  footer?: ReactNode
  className?: string
}

/**
 * Base card used anywhere the shape is "icon + title + description":
 * the "What is FarhadAIStudio" pillars, domain-service items, hosting
 * platforms, and the "Why choose us" grid. Keeping one implementation
 * avoids four near-identical card components.
 */
export default function IconCard({ icon: Icon, title, description, footer, className }: IconCardProps) {
  return (
    <div
      className={cn(
        'group flex flex-col gap-4 rounded-[var(--radius-lg)] border border-border bg-panel p-6 transition-colors hover:border-signal/40',
        className,
      )}
    >
      <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal transition-colors group-hover:bg-signal-soft">
        <Icon size={20} />
      </div>
      <h3 className="text-lg font-semibold text-text">{title}</h3>
      <p className="text-sm text-text-muted">{description}</p>
      {footer && <div className="mt-auto pt-1">{footer}</div>}
    </div>
  )
}
