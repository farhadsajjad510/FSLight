/**
 * Suspense fallback shown while a lazily-loaded route chunk downloads.
 * Kept minimal and on-brand (mono blinking cursor) rather than a spinner.
 */
export default function PageLoader() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <span className="font-mono text-sm text-text-faint">
        loading<span className="animate-pulse text-signal">_</span>
      </span>
    </div>
  )
}
