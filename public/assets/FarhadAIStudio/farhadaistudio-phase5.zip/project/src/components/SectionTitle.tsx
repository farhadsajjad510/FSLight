import type { ReactNode } from 'react'
import { cn } from '@/utils/cn'

interface SectionTitleProps {
  eyebrow?: string
  title: ReactNode
  description?: ReactNode
  align?: 'left' | 'center'
  className?: string
}

/**
 * Standard section heading. The eyebrow is styled like a code comment
 * ("// eyebrow") to keep the developer vocabulary consistent everywhere
 * a section needs to introduce itself.
 */
export default function SectionTitle({
  eyebrow,
  title,
  description,
  align = 'left',
  className,
}: SectionTitleProps) {
  return (
    <div
      className={cn(
        'flex flex-col gap-3',
        align === 'center' && 'items-center text-center',
        className,
      )}
    >
      {eyebrow && (
        <span className="font-mono text-xs tracking-wide text-signal">
          <span className="text-text-faint">// </span>
          {eyebrow}
        </span>
      )}
      <h2 className="text-3xl sm:text-4xl font-semibold text-text text-balance">{title}</h2>
      {description && (
        <p
          className={cn(
            'text-text-muted text-base sm:text-lg max-w-2xl',
            align === 'center' && 'mx-auto',
          )}
        >
          {description}
        </p>
      )}
    </div>
  )
}
