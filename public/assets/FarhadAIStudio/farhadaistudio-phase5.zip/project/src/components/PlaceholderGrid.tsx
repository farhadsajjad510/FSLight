import Container from './Container'

interface PlaceholderGridProps {
  note: string
  count?: number
}

/**
 * Skeleton content grid used on pages whose real content ships in
 * Phase 2. Signals structure without inventing content prematurely.
 */
export default function PlaceholderGrid({ note, count = 6 }: PlaceholderGridProps) {
  return (
    <Container className="py-16 sm:py-20">
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: count }).map((_, i) => (
          <div
            key={i}
            className="flex flex-col gap-3 rounded-[var(--radius-lg)] border border-dashed border-border bg-panel/50 p-6"
          >
            <div className="h-8 w-8 rounded-[var(--radius-sm)] bg-panel-raised" />
            <div className="h-3 w-2/3 rounded-full bg-panel-raised" />
            <div className="h-2.5 w-full rounded-full bg-panel-raised" />
            <div className="h-2.5 w-4/5 rounded-full bg-panel-raised" />
          </div>
        ))}
      </div>
      <p className="mt-8 text-center font-mono text-xs text-text-faint">// {note}</p>
    </Container>
  )
}
