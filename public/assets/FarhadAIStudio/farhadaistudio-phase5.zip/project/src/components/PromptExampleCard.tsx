import { useState } from 'react'
import { Check, Copy } from 'lucide-react'
import type { PromptExample } from '@/data/promptExamples'

interface PromptExampleCardProps {
  example: PromptExample
}

/**
 * Placeholder prompt starter with a working copy-to-clipboard button.
 * No AI request is made here — it only copies the illustrative text.
 */
export default function PromptExampleCard({ example }: PromptExampleCardProps) {
  const [copied, setCopied] = useState(false)
  const Icon = example.icon

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(example.prompt)
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      // Clipboard access can fail silently (e.g. unsupported browser) —
      // no need to surface an error for a non-critical convenience action.
    }
  }

  return (
    <div className="flex flex-col gap-4 rounded-[var(--radius-lg)] border border-border bg-panel p-6 transition-colors hover:border-signal/40">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal">
            <Icon size={16} />
          </div>
          <p className="font-mono text-xs tracking-wide text-text-faint">{example.category}</p>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          aria-label={`Copy ${example.category} prompt example`}
          className="flex items-center gap-1.5 rounded-[var(--radius-sm)] border border-border px-2.5 py-1.5 font-mono text-[11px] text-text-muted transition-colors hover:border-signal/50 hover:text-signal"
        >
          {copied ? <Check size={13} className="text-online" /> : <Copy size={13} />}
          {copied ? 'copied' : 'copy'}
        </button>
      </div>

      <p className="text-sm leading-relaxed text-text-muted">{example.prompt}</p>
    </div>
  )
}
