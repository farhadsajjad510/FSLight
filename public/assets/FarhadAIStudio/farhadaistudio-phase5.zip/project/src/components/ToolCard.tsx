import type { AITool } from '@/data/aiTools'
import Badge from './Badge'

interface ToolCardProps {
  tool: AITool
}

/**
 * Feature card for the AI Coding section — one per assistant (Claude,
 * ChatGPT, Gemini, Farhadoo AI). No API integration in Phase 2; the
 * section-level "Learn more" button is the single CTA for this group.
 */
export default function ToolCard({ tool }: ToolCardProps) {
  return (
    <div className="flex flex-col gap-5 rounded-[var(--radius-lg)] border border-border bg-panel p-6 transition-colors hover:border-signal/40">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-xs text-text-faint">{tool.maker}</p>
          <h3 className="mt-1 text-xl font-semibold text-text">{tool.name}</h3>
        </div>
        <Badge tone={tool.status === 'available' ? 'online' : 'pulse'}>
          {tool.status === 'available' ? 'available' : 'coming soon'}
        </Badge>
      </div>

      <p className="text-sm text-text-muted">{tool.description}</p>

      <div className="flex flex-wrap gap-2">
        {tool.strengths.map((s) => (
          <Badge key={s} tone="muted">
            {s}
          </Badge>
        ))}
      </div>
    </div>
  )
}
