import type { ReactNode } from 'react'
import { cn } from '@/utils/cn'

type Tone = 'signal' | 'pulse' | 'muted' | 'online'

interface BadgeProps {
  children: ReactNode
  tone?: Tone
  className?: string
}

const TONE_STYLES: Record<Tone, string> = {
  signal: 'bg-signal-soft text-signal border-signal/30',
  pulse: 'bg-pulse-soft text-pulse border-pulse/30',
  muted: 'bg-panel-raised text-text-muted border-border',
  online: 'bg-panel-raised text-online border-online/30',
}

/**
 * Small pill used for tech-stack tags, status labels ("coming soon"),
 * and category markers — one component so every tag in the app looks
 * and behaves the same.
 */
export default function Badge({ children, tone = 'muted', className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2.5 py-1 font-mono text-[11px] leading-none tracking-wide',
        TONE_STYLES[tone],
        className,
      )}
    >
      {children}
    </span>
  )
}
