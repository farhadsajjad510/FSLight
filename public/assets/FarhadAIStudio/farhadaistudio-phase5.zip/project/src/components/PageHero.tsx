import type { ReactNode } from 'react'
import Container from './Container'

interface PageHeroProps {
  eyebrow: string
  title: string
  description: string
  children?: ReactNode
}

/**
 * Shared header block for interior (non-home) pages. Keeps the eyebrow /
 * title / description rhythm identical across routes so Phase 2 content
 * can drop in beneath it without new layout work.
 */
export default function PageHero({ eyebrow, title, description, children }: PageHeroProps) {
  return (
    <section className="border-b border-border bg-grid">
      <Container className="flex flex-col gap-4 py-16 sm:py-20">
        <span className="font-mono text-xs text-signal">
          <span className="text-text-faint">// </span>
          {eyebrow}
        </span>
        <h1 className="max-w-2xl text-4xl sm:text-5xl font-semibold text-text text-balance">
          {title}
        </h1>
        <p className="max-w-xl text-base sm:text-lg text-text-muted">{description}</p>
        {children}
      </Container>
    </section>
  )
}
