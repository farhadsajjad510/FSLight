import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronDown } from 'lucide-react'
import type { FAQItem } from '@/data/faqs'

interface FAQAccordionProps {
  items: FAQItem[]
}

/**
 * Single-open accordion for the AI Coding FAQ section. Built as one
 * component (rather than per-item state) so opening one entry closes
 * any other automatically.
 */
export default function FAQAccordion({ items }: FAQAccordionProps) {
  const [openId, setOpenId] = useState<string | null>(items[0]?.id ?? null)

  return (
    <div className="flex flex-col divide-y divide-border rounded-[var(--radius-lg)] border border-border bg-panel">
      {items.map((item) => {
        const isOpen = openId === item.id
        return (
          <div key={item.id}>
            <button
              type="button"
              onClick={() => setOpenId(isOpen ? null : item.id)}
              aria-expanded={isOpen}
              className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6"
            >
              <span className="text-sm sm:text-base font-medium text-text">{item.question}</span>
              <ChevronDown
                size={18}
                className={`shrink-0 text-text-faint transition-transform duration-200 ${
                  isOpen ? 'rotate-180 text-signal' : ''
                }`}
              />
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-5 text-sm text-text-muted sm:px-6">{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )
      })}
    </div>
  )
}
