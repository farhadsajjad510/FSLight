import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { cn } from '@/utils/cn'

type Variant = 'primary' | 'secondary' | 'ghost'
type Size = 'sm' | 'md' | 'lg'

interface ButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement> & AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  variant?: Variant
  size?: Size
  icon?: ReactNode
  iconPosition?: 'left' | 'right'
  className?: string
  children: ReactNode
  /** Internal route — renders a react-router <Link>. */
  to?: string
  /** External URL — renders a plain <a>. */
  href?: string
}

const VARIANT_STYLES: Record<Variant, string> = {
  primary:
    'bg-signal text-ink hover:bg-signal-dim shadow-[var(--shadow-signal)] hover:shadow-none',
  secondary:
    'bg-panel-raised text-text border border-border hover:border-signal/50 hover:text-signal',
  ghost: 'text-text-muted hover:text-text',
}

const SIZE_STYLES: Record<Size, string> = {
  sm: 'text-xs px-3.5 py-2 gap-1.5',
  md: 'text-sm px-5 py-2.5 gap-2',
  lg: 'text-base px-6 py-3.5 gap-2.5',
}

const BASE =
  'inline-flex items-center justify-center font-mono font-medium tracking-tight rounded-[var(--radius-sm)] transition-all duration-150 disabled:opacity-40 disabled:pointer-events-none whitespace-nowrap'

/**
 * Reusable action control. Renders a <Link> when `to` is passed, a plain
 * <a> when `href` is passed, or a <button> otherwise — one component to
 * reach for regardless of destination.
 */
export default function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'right',
  className,
  children,
  to,
  href,
  type,
  ...rest
}: ButtonProps) {
  const classes = cn(BASE, VARIANT_STYLES[variant], SIZE_STYLES[size], className)
  const content = (
    <>
      {icon && iconPosition === 'left' && <span className="shrink-0">{icon}</span>}
      {children}
      {icon && iconPosition === 'right' && <span className="shrink-0">{icon}</span>}
    </>
  )

  if (to) {
    return (
      <Link to={to} className={classes} {...(rest as AnchorHTMLAttributes<HTMLAnchorElement>)}>
        {content}
      </Link>
    )
  }

  if (href) {
    return (
      <a href={href} className={classes} {...(rest as AnchorHTMLAttributes<HTMLAnchorElement>)}>
        {content}
      </a>
    )
  }

  return (
    <button
      type={type ?? 'button'}
      className={classes}
      {...(rest as ButtonHTMLAttributes<HTMLButtonElement>)}
    >
      {content}
    </button>
  )
}
