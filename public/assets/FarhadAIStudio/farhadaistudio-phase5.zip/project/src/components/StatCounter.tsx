import { useEffect, useRef, useState } from 'react'
import { animate, useInView } from 'framer-motion'
import type { LucideIcon } from 'lucide-react'

interface StatCounterProps {
  icon: LucideIcon
  value: number
  suffix?: string
  label: string
}

/**
 * Counts up from 0 to `value` once it scrolls into view. Purely a
 * visual flourish — the underlying values are static placeholders,
 * nothing is fetched.
 */
export default function StatCounter({ icon: Icon, value, suffix = '', label }: StatCounterProps) {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  const [display, setDisplay] = useState(0)

  useEffect(() => {
    if (!isInView) return
    const controls = animate(0, value, {
      duration: 1.4,
      ease: 'easeOut',
      onUpdate: (latest) => setDisplay(Math.round(latest)),
    })
    return () => controls.stop()
  }, [isInView, value])

  return (
    <div
      ref={ref}
      className="flex flex-col items-center gap-3 rounded-[var(--radius-lg)] border border-border bg-panel px-6 py-8 text-center transition-colors hover:border-signal/40"
    >
      <div className="flex h-11 w-11 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal">
        <Icon size={20} />
      </div>
      <p className="font-display text-3xl sm:text-4xl font-semibold text-text">
        {display}
        {suffix}
      </p>
      <p className="font-mono text-xs tracking-wide text-text-faint">{label}</p>
    </div>
  )
}
