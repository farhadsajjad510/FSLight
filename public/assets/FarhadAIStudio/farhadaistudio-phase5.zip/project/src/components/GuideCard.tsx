import type { DeploymentGuide } from '@/data/deploymentGuides'
import Badge from './Badge'

interface GuideCardProps {
  guide: DeploymentGuide
}

/**
 * Informational resource card — no interactive deploy flow, just a
 * description and estimated read time.
 */
export default function GuideCard({ guide }: GuideCardProps) {
  return (
    <div className="flex flex-col gap-4 rounded-[var(--radius-lg)] border border-border bg-panel p-6 transition-colors hover:border-signal/40">
      <div className="flex items-start justify-between gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal">
          <guide.icon size={18} />
        </div>
        <Badge tone="muted">{guide.readTime}</Badge>
      </div>

      <h3 className="text-base font-semibold text-text">{guide.title}</h3>
      <p className="text-sm text-text-muted">{guide.description}</p>
    </div>
  )
}
