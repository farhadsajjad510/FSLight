import { ArrowUpRight, ImageIcon } from 'lucide-react'
import type { ProjectCard } from '@/types'
import Badge from './Badge'
import Button from './Button'

interface FeaturedProjectCardProps {
  project: ProjectCard
}

const STATUS_LABEL: Record<ProjectCard['status'], string> = {
  shipped: 'shipped',
  'in-progress': 'in progress',
  concept: 'concept',
}

const STATUS_TONE: Record<ProjectCard['status'], 'online' | 'signal' | 'pulse'> = {
  shipped: 'online',
  'in-progress': 'signal',
  concept: 'pulse',
}

/**
 * Card for the Featured Projects section. Full case studies live on the
 * Projects page in Phase 2/3 — this links out via "View details" rather
 * than expanding inline, keeping the homepage grid lightweight.
 */
export default function FeaturedProjectCard({ project }: FeaturedProjectCardProps) {
  return (
    <div className="flex flex-col overflow-hidden rounded-[var(--radius-lg)] border border-border bg-panel transition-colors hover:border-signal/40">
      <div className="flex aspect-video items-center justify-center border-b border-border bg-panel-raised bg-grid">
        <ImageIcon size={28} className="text-text-faint" aria-hidden="true" />
      </div>

      <div className="flex flex-1 flex-col gap-4 p-6">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-lg font-semibold text-text">{project.title}</h3>
          <Badge tone={STATUS_TONE[project.status]}>{STATUS_LABEL[project.status]}</Badge>
        </div>

        <p className="text-sm text-text-muted">{project.summary}</p>

        <div className="flex flex-wrap gap-2">
          {project.stack.map((tech) => (
            <Badge key={tech} tone="muted">
              {tech}
            </Badge>
          ))}
        </div>

        <Button
          to="/projects"
          variant="ghost"
          size="sm"
          icon={<ArrowUpRight size={14} />}
          className="mt-auto w-fit"
        >
          View details
        </Button>
      </div>
    </div>
  )
}
