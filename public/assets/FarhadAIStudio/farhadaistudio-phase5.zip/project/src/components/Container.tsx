import type { HTMLAttributes } from 'react'
import { cn } from '@/utils/cn'

interface ContainerProps extends HTMLAttributes<HTMLDivElement> {
  size?: 'default' | 'narrow' | 'wide'
}

const SIZES: Record<NonNullable<ContainerProps['size']>, string> = {
  narrow: 'max-w-3xl',
  default: 'max-w-6xl',
  wide: 'max-w-7xl',
}

/**
 * Layout primitive that centers content and applies consistent
 * horizontal gutters across breakpoints. Use for every top-level
 * section wrapper so page rhythm stays consistent.
 */
export default function Container({ size = 'default', className, ...props }: ContainerProps) {
  return (
    <div className={cn('mx-auto w-full px-5 sm:px-8 lg:px-10', SIZES[size], className)} {...props} />
  )
}
