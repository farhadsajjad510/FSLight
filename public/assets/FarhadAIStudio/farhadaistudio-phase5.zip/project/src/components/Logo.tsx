import { Link } from 'react-router-dom'
import { cn } from '@/utils/cn'

interface LogoProps {
  className?: string
}

/**
 * Text-based brand mark (Phase 1 placeholder — swap for an SVG mark in
 * a later phase without touching call sites). The bracketed glyph reads
 * as a CLI prompt, tying the mark to the developer-platform subject.
 */
export default function Logo({ className }: LogoProps) {
  return (
    <Link
      to="/"
      className={cn(
        'inline-flex items-center gap-2 font-display text-lg font-semibold text-text',
        className,
      )}
      aria-label="FarhadAIStudio home"
    >
      <span
        className="flex h-7 w-7 items-center justify-center rounded-[var(--radius-sm)] bg-panel-raised border border-border font-mono text-sm text-signal"
        aria-hidden="true"
      >
        &gt;_
      </span>
      <span>
        Farhad<span className="text-signal">AI</span>Studio
      </span>
    </Link>
  )
}
