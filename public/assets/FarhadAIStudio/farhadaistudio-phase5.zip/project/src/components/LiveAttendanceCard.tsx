import { ArrowUpRight, CheckCircle2, ImageIcon } from 'lucide-react'
import type { LiveAttendanceProject } from '@/data/liveAttendanceProject'
import Badge from './Badge'
import Button from './Button'

interface LiveAttendanceCardProps {
  project: LiveAttendanceProject
}

const STATUS_LABEL: Record<LiveAttendanceProject['status'], string> = {
  shipped: 'shipped',
  'in-progress': 'in progress',
}

/**
 * Live Attendance is shown as a fully independent product — the
 * "Open Project" button links out to it, nothing from that app is
 * embedded here.
 */
export default function LiveAttendanceCard({ project }: LiveAttendanceCardProps) {
  return (
    <div className="grid grid-cols-1 overflow-hidden rounded-[var(--radius-xl)] border border-border bg-panel lg:grid-cols-2">
      <div className="flex aspect-video items-center justify-center border-b border-border bg-panel-raised bg-grid lg:aspect-auto lg:border-b-0 lg:border-r">
        <ImageIcon size={40} className="text-text-faint" aria-hidden="true" />
      </div>

      <div className="flex flex-col gap-5 p-7 sm:p-10">
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone="signal">v{project.version.replace(/^v/i, '')}</Badge>
          <Badge tone={project.status === 'shipped' ? 'online' : 'pulse'}>
            {STATUS_LABEL[project.status]}
          </Badge>
        </div>

        <div>
          <p className="font-mono text-xs text-text-faint">FarhadAIStudio product</p>
          <h3 className="mt-1 text-2xl sm:text-3xl font-semibold text-text">Live Attendance</h3>
        </div>

        <p className="text-sm text-text-muted">{project.intro}</p>
        <p className="text-sm text-text-muted">
          <span className="text-text-faint">Purpose —</span> {project.purpose}
        </p>

        <div>
          <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">
            key features
          </p>
          <ul className="flex flex-col gap-1.5">
            {project.keyFeatures.map((feature) => (
              <li key={feature} className="flex items-start gap-2 text-sm text-text-muted">
                <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-online" />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="mb-2 font-mono text-[11px] tracking-wide text-text-faint">
            technologies used
          </p>
          <div className="flex flex-wrap gap-2">
            {project.technologies.map((tech) => (
              <Badge key={tech} tone="muted">
                {tech}
              </Badge>
            ))}
          </div>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-3">
          <Button
            href={project.openProjectHref}
            icon={<ArrowUpRight size={16} />}
            target="_blank"
            rel="noopener noreferrer"
          >
            Open Project
          </Button>
          <Button to={project.learnMoreHref} variant="secondary">
            Learn more
          </Button>
        </div>
      </div>
    </div>
  )
}
