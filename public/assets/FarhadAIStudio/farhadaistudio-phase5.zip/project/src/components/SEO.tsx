import { Helmet } from 'react-helmet-async'
import { SITE } from '@/constants/site'

interface SEOProps {
  title?: string
  description?: string
  path?: string
}

/**
 * Per-page SEO tags. Falls back to site-wide defaults so every page is
 * covered even before Phase 2 content is written.
 */
export default function SEO({ title, description, path = '/' }: SEOProps) {
  const pageTitle = title ? `${title} — ${SITE.name}` : `${SITE.name} — ${SITE.tagline}`
  const pageDescription = description ?? SITE.description
  const url = `${SITE.url}${path}`

  return (
    <Helmet>
      <title>{pageTitle}</title>
      <meta name="description" content={pageDescription} />
      <link rel="canonical" href={url} />

      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={pageDescription} />
      <meta property="og:url" content={url} />

      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={pageDescription} />
    </Helmet>
  )
}
