import type { WithChildren } from '@/types'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'

/**
 * Shared page chrome. Every route in the app renders inside this layout
 * so the nav/footer stay consistent without repeating markup per page.
 */
export default function MainLayout({ children }: WithChildren) {
  return (
    <div className="flex min-h-screen flex-col bg-ink">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}
