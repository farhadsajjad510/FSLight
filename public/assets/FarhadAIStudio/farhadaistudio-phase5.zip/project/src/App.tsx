import { Suspense, lazy } from 'react'
import { Routes, Route } from 'react-router-dom'
import MainLayout from '@/layouts/MainLayout'
import PageLoader from '@/components/PageLoader'

const Home = lazy(() => import('@/pages/Home'))
const AICoding = lazy(() => import('@/pages/AICoding'))
const DomainHosting = lazy(() => import('@/pages/DomainHosting'))
const Projects = lazy(() => import('@/pages/Projects'))
const Resources = lazy(() => import('@/pages/Resources'))
const Contact = lazy(() => import('@/pages/Contact'))
const Privacy = lazy(() => import('@/pages/Privacy'))
const Terms = lazy(() => import('@/pages/Terms'))
const NotFound = lazy(() => import('@/pages/NotFound'))

/**
 * Route table. Every page is code-split via React.lazy so the initial
 * bundle only pays for the route being visited; MainLayout wraps every
 * route so nav/footer never re-mount on navigation.
 */
export default function App() {
  return (
    <MainLayout>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ai-coding" element={<AICoding />} />
          <Route path="/domain-hosting" element={<DomainHosting />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </MainLayout>
  )
}
