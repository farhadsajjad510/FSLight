import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import StatCounter from '@/components/StatCounter'
import { PROJECT_STATS } from '@/data/projectStats'

export default function ProjectStats() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle eyebrow="project statistics" title="A quick snapshot" align="center" />

        <div className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {PROJECT_STATS.map((stat) => (
            <StatCounter
              key={stat.id}
              icon={stat.icon}
              value={stat.value}
              suffix={stat.suffix}
              label={stat.label}
            />
          ))}
        </div>
      </Container>
    </section>
  )
}
