import { ArrowRight, MessageCircle, Sparkles } from 'lucide-react'
import Container from '@/components/Container'
import Button from '@/components/Button'

export default function CTA() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <div className="relative overflow-hidden rounded-[var(--radius-xl)] border border-border bg-panel px-8 py-14 text-center sm:px-16 sm:py-20">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_0%,rgba(108,140,255,0.12),transparent)]"
            aria-hidden="true"
          />
          <div className="relative flex flex-col items-center gap-5">
            <span className="font-mono text-xs text-signal">// keep exploring</span>
            <h2 className="max-w-xl text-3xl sm:text-4xl font-semibold text-text text-balance">
              Curious how any of this comes together?
            </h2>
            <p className="max-w-md text-text-muted">
              Learn the AI coding workflow behind these builds, see how they get deployed, or
              reach out directly.
            </p>
            <div className="mt-2 flex flex-wrap items-center justify-center gap-3">
              <Button to="/ai-coding" icon={<Sparkles size={16} />}>
                Explore AI coding
              </Button>
              <Button to="/domain-hosting" variant="secondary" icon={<ArrowRight size={16} />}>
                Learn deployment
              </Button>
              <Button to="/contact" variant="secondary" icon={<MessageCircle size={16} />}>
                Contact FarhadAIStudio
              </Button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  )
}
