import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import LiveAttendanceCard from '@/components/LiveAttendanceCard'
import { LIVE_ATTENDANCE } from '@/data/liveAttendanceProject'

export default function LiveAttendance() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle eyebrow="featured project" title="Live Attendance" />

        <div className="mt-10">
          <LiveAttendanceCard project={LIVE_ATTENDANCE} />
        </div>
      </Container>
    </section>
  )
}
