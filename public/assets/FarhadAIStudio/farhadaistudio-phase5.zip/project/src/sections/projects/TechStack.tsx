import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import Badge from '@/components/Badge'
import { TECH_STACK } from '@/data/techStack'

export default function TechStack() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="technology stack"
          title="What powers these projects"
          align="center"
        />

        <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {TECH_STACK.map(({ id, icon: Icon, label, future }) => (
            <div
              key={id}
              className="flex flex-col items-center gap-3 rounded-[var(--radius-lg)] border border-border bg-panel px-3 py-6 text-center transition-colors hover:border-signal/40"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal">
                <Icon size={18} />
              </div>
              <span className="text-xs text-text-muted">{label}</span>
              {future && (
                <Badge tone="pulse" className="text-[10px]">
                  future
                </Badge>
              )}
            </div>
          ))}
        </div>
      </Container>
    </section>
  )
}
