import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import { DEVELOPMENT_WORKFLOW } from '@/data/developmentWorkflow'

export default function DevelopmentTimeline() {
  return (
    <section className="py-20 sm:py-28">
      <Container size="narrow">
        <SectionTitle
          eyebrow="development workflow"
          title="The same process, every project"
          align="center"
        />

        <div className="mt-14 flex flex-col gap-8 border-l border-border pl-8 sm:pl-10">
          {DEVELOPMENT_WORKFLOW.map((phase, index) => (
            <div key={phase.id} className="relative">
              <span className="absolute -left-[41px] top-0 flex h-8 w-8 items-center justify-center rounded-full border border-border bg-panel text-signal sm:-left-[49px]">
                <phase.icon size={15} />
              </span>
              <p className="font-mono text-[11px] tracking-wide text-text-faint">
                step {index + 1 < 10 ? `0${index + 1}` : index + 1}
              </p>
              <h3 className="mt-1 text-lg font-semibold text-text">{phase.title}</h3>
              <p className="mt-1 text-sm text-text-muted">{phase.description}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  )
}
