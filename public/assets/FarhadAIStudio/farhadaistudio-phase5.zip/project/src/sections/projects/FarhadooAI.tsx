import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import FarhadooAICard from '@/components/FarhadooAICard'
import { FARHADOO_AI } from '@/data/farhadooAI'

export default function FarhadooAI() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle eyebrow="featured project" title="Farhadoo AI" />

        <div className="mt-10">
          <FarhadooAICard project={FARHADOO_AI} />
        </div>
      </Container>
    </section>
  )
}
