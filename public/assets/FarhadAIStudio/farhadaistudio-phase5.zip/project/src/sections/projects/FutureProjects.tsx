import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import FutureProjectCard from '@/components/FutureProjectCard'
import { FUTURE_PROJECTS } from '@/data/futureProjects'

export default function FutureProjects() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="what's next"
          title="Future products"
          description="Early ideas taking shape under the FarhadAIStudio brand — nothing here is built yet."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FUTURE_PROJECTS.map((project) => (
            <FutureProjectCard key={project.id} project={project} />
          ))}
        </div>
      </Container>
    </section>
  )
}
