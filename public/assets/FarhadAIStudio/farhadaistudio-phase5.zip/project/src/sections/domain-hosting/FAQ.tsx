import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import FAQAccordion from '@/components/FAQAccordion'
import { DOMAIN_HOSTING_FAQS } from '@/data/domainHostingFaqs'

export default function FAQ() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container size="narrow">
        <SectionTitle eyebrow="faq" title="Frequently asked questions" align="center" />

        <div className="mt-12">
          <FAQAccordion items={DOMAIN_HOSTING_FAQS} />
        </div>
      </Container>
    </section>
  )
}
