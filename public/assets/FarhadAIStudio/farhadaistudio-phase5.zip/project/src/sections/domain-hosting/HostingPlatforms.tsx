import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import HostingPlatformCard from '@/components/HostingPlatformCard'
import { HOSTING_PLATFORMS_DETAILED } from '@/data/hostingPlatformsDetailed'

export default function HostingPlatforms() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="hosting platforms"
          title="Where to actually ship your project"
          description="A closer comparison of the platforms developers reach for most — so you can pick with confidence."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {HOSTING_PLATFORMS_DETAILED.map((platform) => (
            <HostingPlatformCard key={platform.id} platform={platform} />
          ))}
        </div>
      </Container>
    </section>
  )
}
