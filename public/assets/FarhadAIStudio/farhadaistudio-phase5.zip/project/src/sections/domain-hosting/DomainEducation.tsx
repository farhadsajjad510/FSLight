import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import IconCard from '@/components/IconCard'
import Badge from '@/components/Badge'
import { DOMAIN_TOPICS } from '@/data/domainTopics'

const POPULAR_EXTENSIONS = ['.com', '.net', '.org', '.ai', '.io', '.dev', '.app', '.co']

export default function DomainEducation() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="understanding domains"
          title="Get your domain right, the first time"
          description="The concepts worth knowing before you register anything — no registrar built in, just what actually matters."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {DOMAIN_TOPICS.map(({ id, icon, title, description }) => (
            <IconCard key={id} icon={icon} title={title} description={description} />
          ))}
        </div>

        <div className="mt-8 flex flex-col gap-4 rounded-[var(--radius-lg)] border border-dashed border-border bg-panel/50 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-mono text-xs text-signal">// popular extensions</p>
            <p className="mt-1 text-sm text-text-muted">
              The extension shapes first impressions — pick one that fits your project.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {POPULAR_EXTENSIONS.map((ext) => (
              <Badge key={ext} tone="muted">
                {ext}
              </Badge>
            ))}
          </div>
        </div>
      </Container>
    </section>
  )
}
