import { motion } from 'framer-motion'
import { Globe2 } from 'lucide-react'
import Container from '@/components/Container'

export default function Intro() {
  return (
    <section className="relative overflow-hidden border-b border-border bg-grid">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(108,140,255,0.10),transparent)]"
        aria-hidden="true"
      />
      <Container className="relative flex flex-col gap-5 py-16 sm:py-24">
        <motion.span
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex w-fit items-center gap-2 rounded-full border border-border bg-panel px-3 py-1.5 font-mono text-xs text-text-muted"
        >
          <Globe2 size={13} className="text-pulse" />
          domain & hosting hub
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.05 }}
          className="max-w-2xl text-4xl sm:text-5xl font-semibold text-text text-balance"
        >
          Domains, hosting, and going live
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="max-w-xl text-base sm:text-lg text-text-muted"
        >
          Everything you need to understand before a project goes from local to live —
          choosing a domain, comparing hosts, deploying safely, and launching with confidence.
        </motion.p>
      </Container>
    </section>
  )
}
