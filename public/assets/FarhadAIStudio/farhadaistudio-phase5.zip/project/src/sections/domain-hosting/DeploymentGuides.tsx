import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import GuideCard from '@/components/GuideCard'
import { DEPLOYMENT_GUIDES } from '@/data/deploymentGuides'

export default function DeploymentGuides() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="deployment guides"
          title="Beginner-friendly, step by step"
          description="Informational overviews of the most common deploy paths — pick the one that matches your host."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {DEPLOYMENT_GUIDES.map((guide) => (
            <GuideCard key={guide.id} guide={guide} />
          ))}
        </div>
      </Container>
    </section>
  )
}
