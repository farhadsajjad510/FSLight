import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import { RECOMMENDED_TOOLS } from '@/data/devTools'

export default function RecommendedTools() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="recommended tools"
          title="What most developers already reach for"
          description="A quick reference — no accounts required to read this list."
          align="center"
        />

        <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {RECOMMENDED_TOOLS.map(({ id, icon: Icon, label }) => (
            <div
              key={id}
              className="flex flex-col items-center gap-3 rounded-[var(--radius-lg)] border border-border bg-panel px-4 py-6 text-center transition-colors hover:border-signal/40"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal">
                <Icon size={18} />
              </div>
              <span className="text-xs text-text-muted">{label}</span>
            </div>
          ))}
        </div>
      </Container>
    </section>
  )
}
