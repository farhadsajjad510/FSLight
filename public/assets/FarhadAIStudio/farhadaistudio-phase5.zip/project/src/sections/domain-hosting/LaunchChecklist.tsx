import { useState } from 'react'
import { CheckCircle2, Circle } from 'lucide-react'
import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import { LAUNCH_CHECKLIST } from '@/data/launchChecklist'

/**
 * A self-check list before going live. Checked state lives only in
 * local component state — nothing is saved, synced, or sent anywhere.
 */
export default function LaunchChecklist() {
  const [checked, setChecked] = useState<Set<string>>(new Set())

  function toggle(id: string) {
    setChecked((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container size="narrow">
        <SectionTitle
          eyebrow="website launch checklist"
          title="Before you hit deploy"
          description="A quick self-check — tap each item as you cover it. Nothing here is saved, it's just a sanity pass."
          align="center"
        />

        <div className="mt-12 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {LAUNCH_CHECKLIST.map((item) => {
            const isChecked = checked.has(item.id)
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => toggle(item.id)}
                aria-pressed={isChecked}
                className="flex items-center gap-3 rounded-[var(--radius-md)] border border-border bg-panel px-4 py-3.5 text-left transition-colors hover:border-signal/40"
              >
                {isChecked ? (
                  <CheckCircle2 size={18} className="shrink-0 text-online" />
                ) : (
                  <Circle size={18} className="shrink-0 text-text-faint" />
                )}
                <span className={isChecked ? 'text-sm text-text line-through decoration-text-faint' : 'text-sm text-text'}>
                  {item.label}
                </span>
              </button>
            )
          })}
        </div>
      </Container>
    </section>
  )
}
