import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import AIModelCard from '@/components/AIModelCard'
import { AI_MODELS } from '@/data/aiModels'

export default function FeaturedModels() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="featured ai models"
          title="The assistants worth knowing"
          description="A closer look at what each major coding assistant is actually good at — so you can pick the right one for the task in front of you."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 lg:grid-cols-3">
          {AI_MODELS.map((model) => (
            <AIModelCard key={model.id} model={model} />
          ))}
        </div>
      </Container>
    </section>
  )
}
