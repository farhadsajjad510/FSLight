import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import IconCard from '@/components/IconCard'
import { BEST_PRACTICES } from '@/data/bestPractices'

export default function BestPractices() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="ai best practices"
          title="Use AI well, not just fast"
          description="A few habits that keep AI-assisted development safe, understandable, and actually maintainable."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {BEST_PRACTICES.map(({ id, icon, title, description }) => (
            <IconCard key={id} icon={icon} title={title} description={description} />
          ))}
        </div>
      </Container>
    </section>
  )
}
