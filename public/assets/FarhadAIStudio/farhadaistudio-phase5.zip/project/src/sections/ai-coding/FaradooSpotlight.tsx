import { Code2, GraduationCap, Compass, Bot } from 'lucide-react'
import Container from '@/components/Container'
import Badge from '@/components/Badge'

const PLACEHOLDER_CAPABILITIES = [
  { icon: Code2, label: 'AI Coding' },
  { icon: GraduationCap, label: 'AI Learning' },
  { icon: Compass, label: 'AI Project Guidance' },
  { icon: Bot, label: 'AI Development Assistant' },
]

/**
 * Highlight for Faradoo AI — FarhadAIStudio's own upcoming assistant.
 * Placeholder capabilities only; no functionality is built or wired
 * up here.
 */
export default function FaradooSpotlight() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <div className="relative overflow-hidden rounded-[var(--radius-xl)] border border-signal/30 bg-panel px-6 py-12 sm:px-12 sm:py-16">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_0%,rgba(245,166,35,0.14),transparent)]"
            aria-hidden="true"
          />
          <div className="relative flex flex-col items-center gap-5 text-center">
            <Badge tone="pulse">in development</Badge>
            <span className="font-mono text-xs text-signal">// the future product</span>
            <h2 className="max-w-xl text-3xl sm:text-4xl font-semibold text-text text-balance">
              Faradoo AI — built under the FarhadAIStudio brand
            </h2>
            <p className="max-w-lg text-text-muted">
              Faradoo AI is an upcoming assistant purpose-built for this platform's
              workflows — not a general chatbot bolted on afterward. It's early, and
              nothing below is live yet.
            </p>

            <div className="mt-4 grid w-full max-w-2xl grid-cols-2 gap-3 sm:grid-cols-4">
              {PLACEHOLDER_CAPABILITIES.map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  className="flex flex-col items-center gap-2 rounded-[var(--radius-md)] border border-dashed border-border bg-panel-raised/60 px-3 py-5"
                >
                  <Icon size={18} className="text-text-faint" />
                  <span className="text-center text-xs text-text-muted">{label}</span>
                </div>
              ))}
            </div>

            <p className="mt-2 font-mono text-xs text-text-faint">
              // placeholders — capabilities land in a future phase
            </p>
          </div>
        </div>
      </Container>
    </section>
  )
}
