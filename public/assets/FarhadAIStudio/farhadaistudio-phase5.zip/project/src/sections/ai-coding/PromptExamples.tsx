import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import PromptExampleCard from '@/components/PromptExampleCard'
import { PROMPT_EXAMPLES } from '@/data/promptExamples'

export default function PromptExamples() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="prompt examples"
          title="Starting points, not scripts"
          description="Copy one of these and adapt it with your own context — the more specific the prompt, the better the result."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PROMPT_EXAMPLES.map((example) => (
            <PromptExampleCard key={example.id} example={example} />
          ))}
        </div>
      </Container>
    </section>
  )
}
