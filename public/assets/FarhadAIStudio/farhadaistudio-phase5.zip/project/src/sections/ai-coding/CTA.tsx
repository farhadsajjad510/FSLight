import { ArrowRight, FolderGit2, MessageCircle } from 'lucide-react'
import Container from '@/components/Container'
import Button from '@/components/Button'

export default function CTA() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <div className="relative overflow-hidden rounded-[var(--radius-xl)] border border-border bg-panel px-8 py-14 text-center sm:px-16 sm:py-20">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_0%,rgba(108,140,255,0.12),transparent)]"
            aria-hidden="true"
          />
          <div className="relative flex flex-col items-center gap-5">
            <span className="font-mono text-xs text-signal">// put it into practice</span>
            <h2 className="max-w-xl text-3xl sm:text-4xl font-semibold text-text text-balance">
              Ready to build with AI in the loop?
            </h2>
            <p className="max-w-md text-text-muted">
              See real projects, learn how to deploy what you build, or reach out directly for
              development help.
            </p>
            <div className="mt-2 flex flex-wrap items-center justify-center gap-3">
              <Button to="/projects" icon={<FolderGit2 size={16} />}>
                Explore projects
              </Button>
              <Button to="/domain-hosting" variant="secondary" icon={<ArrowRight size={16} />}>
                Learn deployment
              </Button>
              <Button to="/contact" variant="secondary" icon={<MessageCircle size={16} />}>
                Contact FarhadAIStudio
              </Button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  )
}
