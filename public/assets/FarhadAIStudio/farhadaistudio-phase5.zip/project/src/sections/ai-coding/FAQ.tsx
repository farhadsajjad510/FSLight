import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import FAQAccordion from '@/components/FAQAccordion'
import { AI_CODING_FAQS } from '@/data/faqs'

export default function FAQ() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container size="narrow">
        <SectionTitle eyebrow="faq" title="Frequently asked questions" align="center" />

        <div className="mt-12">
          <FAQAccordion items={AI_CODING_FAQS} />
        </div>
      </Container>
    </section>
  )
}
