import { motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import Container from '@/components/Container'

/**
 * Page-opening intro for /ai-coding. A richer variant of PageHero's
 * rhythm (eyebrow / title / description) with a supporting line that
 * frames the whole page as informational, not a tool integration.
 */
export default function Intro() {
  return (
    <section className="relative overflow-hidden border-b border-border bg-grid">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(245,166,35,0.10),transparent)]"
        aria-hidden="true"
      />
      <Container className="relative flex flex-col gap-5 py-16 sm:py-24">
        <motion.span
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex w-fit items-center gap-2 rounded-full border border-border bg-panel px-3 py-1.5 font-mono text-xs text-text-muted"
        >
          <Sparkles size={13} className="text-signal" />
          ai coding hub
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.05 }}
          className="max-w-2xl text-4xl sm:text-5xl font-semibold text-text text-balance"
        >
          Use AI to build software, faster and better
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="max-w-xl text-base sm:text-lg text-text-muted"
        >
          FarhadAIStudio helps developers understand the AI coding assistants worth knowing,
          how to bring them into a real workflow responsibly, and where this platform's
          own AI — Faradoo AI — is headed next.
        </motion.p>
      </Container>
    </section>
  )
}
