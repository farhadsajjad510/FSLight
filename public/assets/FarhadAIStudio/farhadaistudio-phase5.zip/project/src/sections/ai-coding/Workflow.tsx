import { ChevronRight } from 'lucide-react'
import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import { WORKFLOW_STEPS } from '@/data/workflowSteps'

export default function Workflow() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="ai coding workflow"
          title="From idea to deploy, with AI in the loop"
          description="The same six-step loop, every time — it keeps AI useful without letting it skip the parts that actually matter."
          align="center"
        />

        <div className="mt-14 flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:gap-2">
          {WORKFLOW_STEPS.map((step, index) => (
            <div key={step.id} className="flex flex-1 items-center gap-2 sm:gap-2">
              <div className="flex flex-1 flex-col items-center gap-3 rounded-[var(--radius-lg)] border border-border bg-panel px-4 py-6 text-center transition-colors hover:border-signal/40">
                <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-panel-raised text-signal">
                  <step.icon size={18} />
                </div>
                <p className="text-sm font-semibold text-text">{step.title}</p>
                <p className="text-xs text-text-muted">{step.description}</p>
              </div>

              {index < WORKFLOW_STEPS.length - 1 && (
                <ChevronRight
                  size={18}
                  className="hidden shrink-0 text-text-faint sm:block"
                  aria-hidden="true"
                />
              )}
            </div>
          ))}
        </div>
      </Container>
    </section>
  )
}
