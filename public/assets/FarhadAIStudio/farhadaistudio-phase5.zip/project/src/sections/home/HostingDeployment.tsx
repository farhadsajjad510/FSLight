import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import IconCard from '@/components/IconCard'
import Badge from '@/components/Badge'
import { HOSTING_PLATFORMS } from '@/data/hostingPlatforms'

export default function HostingDeployment() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="hosting & deployment"
          title="Where to actually ship your project"
          description="A quick comparison of the platforms developers reach for most, so you can pick with confidence."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {HOSTING_PLATFORMS.map(({ id, icon, name, description, bestFor }) => (
            <IconCard
              key={id}
              icon={icon}
              title={name}
              description={description}
              footer={<Badge tone="pulse">{bestFor}</Badge>}
            />
          ))}
        </div>
      </Container>
    </section>
  )
}
