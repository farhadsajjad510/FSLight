import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import IconCard from '@/components/IconCard'
import { DOMAIN_SERVICES } from '@/data/domainServices'

export default function DomainServices() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="domain services"
          title="Get your domain right, the first time"
          description="Informational guidance — no registrar built in, just what to know before you buy."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {DOMAIN_SERVICES.map(({ id, icon, title, description }) => (
            <IconCard key={id} icon={icon} title={title} description={description} />
          ))}
        </div>
      </Container>
    </section>
  )
}
