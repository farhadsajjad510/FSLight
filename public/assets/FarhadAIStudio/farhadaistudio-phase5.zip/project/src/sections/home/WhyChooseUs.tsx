import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import IconCard from '@/components/IconCard'
import { WHY_FEATURES } from '@/data/features'

export default function WhyChooseUs() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="why choose farhadaistudio"
          title="Built with the same standards it teaches"
          align="center"
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_FEATURES.map(({ id, icon, title, description }) => (
            <IconCard key={id} icon={icon} title={title} description={description} />
          ))}
        </div>
      </Container>
    </section>
  )
}
