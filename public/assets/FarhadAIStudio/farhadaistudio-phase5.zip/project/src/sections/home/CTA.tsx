import { ArrowRight, FolderGit2, MessageCircle } from 'lucide-react'
import Container from '@/components/Container'
import Button from '@/components/Button'

export default function CTA() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <div className="relative overflow-hidden rounded-[var(--radius-xl)] border border-border bg-panel px-8 py-14 text-center sm:px-16 sm:py-20">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_0%,rgba(245,166,35,0.12),transparent)]"
            aria-hidden="true"
          />
          <div className="relative flex flex-col items-center gap-5">
            <span className="font-mono text-xs text-signal">// ready when you are</span>
            <h2 className="max-w-xl text-3xl sm:text-4xl font-semibold text-text text-balance">
              Have a build in mind? Let&apos;s get it shipped.
            </h2>
            <p className="max-w-md text-text-muted">
              Explore the tools, see the work, or reach out directly — whichever gets you moving
              faster.
            </p>
            <div className="mt-2 flex flex-wrap items-center justify-center gap-3">
              <Button to="/ai-coding" icon={<ArrowRight size={16} />}>
                Explore AI coding
              </Button>
              <Button to="/projects" variant="secondary" icon={<FolderGit2 size={16} />}>
                View projects
              </Button>
              <Button to="/contact" variant="secondary" icon={<MessageCircle size={16} />}>
                Contact us
              </Button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  )
}
