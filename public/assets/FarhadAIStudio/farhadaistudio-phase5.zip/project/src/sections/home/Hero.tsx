import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import Container from '@/components/Container'
import Button from '@/components/Button'

const COMMANDS = [
  'discover ai-coding-tools --curated',
  'learn deployment --step-by-step',
  'explore projects --real-world',
  'connect --with-a-developer',
]

/**
 * Hero signature element: a typed terminal window that cycles through
 * the platform's four core jobs. Ties the visual language directly to
 * the "AI developer platform" subject rather than a generic headline.
 */
function TerminalWindow() {
  const [commandIndex, setCommandIndex] = useState(0)
  const [typed, setTyped] = useState('')
  const [phase, setPhase] = useState<'typing' | 'pausing' | 'deleting'>('typing')

  useEffect(() => {
    const current = COMMANDS[commandIndex]
    let timeout: ReturnType<typeof setTimeout>

    if (phase === 'typing') {
      if (typed.length < current.length) {
        timeout = setTimeout(() => setTyped(current.slice(0, typed.length + 1)), 38)
      } else {
        timeout = setTimeout(() => setPhase('pausing'), 1200)
      }
    } else if (phase === 'pausing') {
      timeout = setTimeout(() => setPhase('deleting'), 500)
    } else {
      if (typed.length > 0) {
        timeout = setTimeout(() => setTyped(typed.slice(0, -1)), 20)
      } else {
        setCommandIndex((i) => (i + 1) % COMMANDS.length)
        setPhase('typing')
      }
    }

    return () => clearTimeout(timeout)
  }, [typed, phase, commandIndex])

  return (
    <div className="w-full rounded-[var(--radius-lg)] border border-border bg-panel shadow-[var(--shadow-panel)] overflow-hidden">
      <div className="flex items-center gap-1.5 border-b border-border bg-panel-raised px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-text-faint/40" />
        <span className="h-2.5 w-2.5 rounded-full bg-text-faint/40" />
        <span className="h-2.5 w-2.5 rounded-full bg-text-faint/40" />
        <span className="ml-3 font-mono text-xs text-text-faint">farhadaistudio — zsh</span>
      </div>
      <div className="px-5 py-6 font-mono text-sm sm:text-base min-h-[120px]">
        <p className="text-text-faint">
          <span className="text-online">➜</span> ~/farhadaistudio
        </p>
        <p className="mt-2 text-text">
          <span className="text-pulse">$</span> {typed}
          <span className="inline-block w-[2px] h-[1em] translate-y-[2px] bg-signal ml-0.5 animate-pulse" />
        </p>
      </div>
    </div>
  )
}

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-grid">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[560px] bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(245,166,35,0.10),transparent)]"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute right-0 top-32 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(108,140,255,0.12),transparent_70%)] blur-2xl"
        aria-hidden="true"
      />
      <Container className="relative flex flex-col gap-14 pb-20 pt-16 sm:pt-24 lg:flex-row lg:items-center lg:gap-10 lg:pb-28 lg:pt-32">
        <div className="flex flex-col gap-6 lg:w-1/2">
          <motion.span
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex w-fit items-center gap-2 rounded-full border border-border bg-panel px-3 py-1.5 font-mono text-xs text-text-muted"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-online" />
            v1 — foundation is live
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.05 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-semibold text-text text-balance"
          >
            Build, learn, and deploy — with AI in the loop.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="max-w-lg text-base sm:text-lg text-text-muted"
          >
            FarhadAIStudio is where developers discover AI coding tools, learn to ship and
            deploy, explore real projects, and connect for hands-on development services —
            in one clean, fast place.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="flex flex-wrap items-center gap-3 pt-2"
          >
            <Button to="/ai-coding" icon={<ArrowRight size={16} />}>
              Explore AI coding tools
            </Button>
            <Button to="/projects" variant="secondary">
              View projects
            </Button>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="lg:w-1/2"
        >
          <TerminalWindow />
        </motion.div>
      </Container>
    </section>
  )
}
