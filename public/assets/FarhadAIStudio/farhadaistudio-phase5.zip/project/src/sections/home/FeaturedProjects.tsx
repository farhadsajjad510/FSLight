import { ArrowRight } from 'lucide-react'
import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import Button from '@/components/Button'
import FeaturedProjectCard from '@/components/FeaturedProjectCard'
import { FEATURED_PROJECTS } from '@/data/projects'

export default function FeaturedProjects() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <SectionTitle
            eyebrow="featured projects"
            title="What's being built here"
            description="A real look at current work — not polished case studies, just honest status."
          />
          <Button to="/projects" variant="secondary" icon={<ArrowRight size={16} />} className="shrink-0">
            View all projects
          </Button>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2">
          {FEATURED_PROJECTS.map((project) => (
            <FeaturedProjectCard key={project.id} project={project} />
          ))}
        </div>
      </Container>
    </section>
  )
}
