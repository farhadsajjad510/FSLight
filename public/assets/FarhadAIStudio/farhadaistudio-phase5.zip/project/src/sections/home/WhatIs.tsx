import { Code2, Globe2, ServerCog, BookOpenText } from 'lucide-react'
import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import IconCard from '@/components/IconCard'

const CAPABILITIES = [
  {
    icon: Code2,
    title: 'Coding assistance',
    description:
      'Compare AI editors, agents, and copilots side by side and find the one that fits how you actually build.',
  },
  {
    icon: Globe2,
    title: 'Domain guidance',
    description:
      'Plain-language help choosing, registering, and securing a domain — no jargon, no upsells.',
  },
  {
    icon: ServerCog,
    title: 'Hosting & deployment',
    description:
      'Straightforward comparisons of where to deploy, from static hosts to full backend platforms.',
  },
  {
    icon: BookOpenText,
    title: 'Development resources',
    description:
      'Guides, references, and checklists written from real day-to-day AI-assisted development.',
  },
]

export default function WhatIs() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow="what is farhadaistudio"
          title="An AI developer platform, built to be used"
          description="FarhadAIStudio brings the four things developers actually need when building with AI into one clean, fast place — not another dashboard to manage."
        />

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {CAPABILITIES.map(({ icon, title, description }) => (
            <IconCard key={title} icon={icon} title={title} description={description} />
          ))}
        </div>
      </Container>
    </section>
  )
}
