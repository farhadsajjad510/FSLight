import { ArrowRight } from 'lucide-react'
import Container from '@/components/Container'
import SectionTitle from '@/components/SectionTitle'
import ToolCard from '@/components/ToolCard'
import Button from '@/components/Button'
import { AI_TOOLS } from '@/data/aiTools'

export default function AICodingSection() {
  return (
    <section className="border-y border-border bg-panel/40 py-20 sm:py-28">
      <Container>
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <SectionTitle
            eyebrow="ai coding"
            title="The assistants worth knowing"
            description="A quick look at where each major coding assistant fits — plus what we're building ourselves."
          />
          <Button to="/ai-coding" variant="secondary" icon={<ArrowRight size={16} />} className="shrink-0">
            Learn more
          </Button>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {AI_TOOLS.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      </Container>
    </section>
  )
}
