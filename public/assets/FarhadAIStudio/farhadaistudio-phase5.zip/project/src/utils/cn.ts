/**
 * Tiny classnames combinator — merges conditional class strings without
 * pulling in an extra dependency for a single utility function.
 */
export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ')
}
