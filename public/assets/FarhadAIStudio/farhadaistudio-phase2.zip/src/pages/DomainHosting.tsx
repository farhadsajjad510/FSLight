import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import PlaceholderGrid from '@/components/PlaceholderGrid'

export default function DomainHosting() {
  return (
    <>
      <SEO
        title="Domain & Hosting"
        description="Learn how to take AI-assisted projects from local to live."
        path="/domain-hosting"
      />
      <PageHero
        eyebrow="ship it"
        title="Domains, hosting, and going live"
        description="Step-by-step deployment guides — from picking a domain to choosing a host to shipping your first production build — land here in Phase 2."
      />
      <PlaceholderGrid note="deployment guides populate in phase 2" count={3} />
    </>
  )
}
