import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import PlaceholderGrid from '@/components/PlaceholderGrid'

export default function AICoding() {
  return (
    <>
      <SEO
        title="AI Coding"
        description="Discover and compare AI coding tools, editors, and agents."
        path="/ai-coding"
      />
      <PageHero
        eyebrow="tool index"
        title="AI coding tools, without the noise"
        description="A curated index of editors, copilots, and coding agents is coming together here — organized by what each tool is actually best at."
      />
      <PlaceholderGrid note="tool cards populate in phase 2" />
    </>
  )
}
