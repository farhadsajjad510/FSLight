import SEO from '@/components/SEO'
import PageHero from '@/components/PageHero'
import PlaceholderGrid from '@/components/PlaceholderGrid'

export default function Projects() {
  return (
    <>
      <SEO
        title="Projects"
        description="Browse real AI-assisted projects — shipped, in progress, and conceptual."
        path="/projects"
      />
      <PageHero
        eyebrow="the work"
        title="Projects, at every stage"
        description="Shipped builds, in-progress work, and early concepts — a real look at what AI-assisted development produces, not just polished case studies."
      />
      <PlaceholderGrid note="project cards populate in phase 2" />
    </>
  )
}
